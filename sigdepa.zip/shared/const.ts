export const COOKIE_NAME = "sigde_session";
export const ONE_YEAR_MS = 1000 * 60 * 60 * 24 * 365;
export const AXIOS_TIMEOUT_MS = 30_000;
export const UNAUTHED_ERR_MSG = "Please login (10001)";
export const NOT_ADMIN_ERR_MSG = "You do not have required permission (10002)";

export const LEGACY_BASE_DECLARATION_TEXT = "Declaramos para todos os fins de direito e a quem possa interessar que o(a) aluno(a) [NOME COMPLETO], nascido(a) em [DATA DE NASCIMENTO], filho(a) de [NOME DA MÃE OU RESPONSÁVEL], matriculou-se neste Estabelecimento de Ensino, no ano letivo de [ANO LETIVO], para cursar a [SÉRIE] do Ensino Médio (SOME REGULAR), na turma [TURMA], no turno da [TURNO], frequentando regularmente as aulas.\n\nPor ser verdade, firmo a presente declaração para que surta efeitos legais.";
export const BASE_DECLARATION_TEXT = "Declaramos para todos os fins de direito e a quem possa interessar que o (a) aluno (a) [NOME COMPLETO], nascido (a) em: [DATA DE NASCIMENTO], filho (a) de: [NOME DA MÃE OU RESPONSÁVEL], matriculou-se neste Estabelecimento de Ensino, no ano letivo de [ANO LETIVO], para cursar a [SÉRIE] do Ensino Médio (SOME REGULAR), na turma [TURMA], no turno da [TURNO], frequentando regularmente as aulas.\n\nPor ser verdade, firmo a presente declaração para que surta efeitos legais.";

export function normalizeDeclarationTemplateContent(content: string | null | undefined) {
  return !content || content === LEGACY_BASE_DECLARATION_TEXT ? BASE_DECLARATION_TEXT : content;
}
