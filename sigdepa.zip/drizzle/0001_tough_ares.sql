CREATE TABLE `auditLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`institutionId` int NOT NULL DEFAULT 1,
	`actorId` int,
	`action` varchar(100) NOT NULL,
	`entityType` varchar(80) NOT NULL,
	`entityId` varchar(80),
	`details` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `auditLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `declarations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`institutionId` int NOT NULL DEFAULT 1,
	`studentId` int,
	`documentNumber` varchar(32) NOT NULL,
	`sequenceYear` int NOT NULL,
	`sequenceNumber` int NOT NULL,
	`issuedAt` date NOT NULL,
	`signerName` varchar(240) NOT NULL,
	`signerRole` varchar(160) NOT NULL,
	`snapshot` json NOT NULL,
	`templateVersion` int NOT NULL DEFAULT 1,
	`status` enum('EMITIDA','CANCELADA') NOT NULL DEFAULT 'EMITIDA',
	`cancellationReason` text,
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `declarations_id` PRIMARY KEY(`id`),
	CONSTRAINT `declarations_institution_number_uq` UNIQUE(`institutionId`,`documentNumber`),
	CONSTRAINT `declarations_institution_year_seq_uq` UNIQUE(`institutionId`,`sequenceYear`,`sequenceNumber`)
);
--> statement-breakpoint
CREATE TABLE `documentSequences` (
	`year` int NOT NULL,
	`lastNumber` int NOT NULL DEFAULT 0,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `documentSequences_year` PRIMARY KEY(`year`)
);
--> statement-breakpoint
CREATE TABLE `documentTemplates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`institutionId` int NOT NULL DEFAULT 1,
	`name` varchar(160) NOT NULL,
	`content` text NOT NULL,
	`version` int NOT NULL DEFAULT 1,
	`active` boolean NOT NULL DEFAULT true,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `documentTemplates_id` PRIMARY KEY(`id`),
	CONSTRAINT `templates_institution_name_version_uq` UNIQUE(`institutionId`,`name`,`version`)
);
--> statement-breakpoint
CREATE TABLE `institutions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(240) NOT NULL,
	`government` varchar(240) NOT NULL DEFAULT 'GOVERNO DO ESTADO DO PARÁ',
	`secretary` varchar(240) NOT NULL DEFAULT 'SECRETARIA EXECUTIVA DE EDUCAÇÃO',
	`regionalOffice` varchar(240) NOT NULL DEFAULT '10ª UNIDADE REGIONAL DE EDUCAÇÃO',
	`address` varchar(320) NOT NULL DEFAULT 'Rua Sete de Setembro, nº 576 – bairro: Centro',
	`municipality` varchar(160) NOT NULL DEFAULT 'Senador José Porfírio',
	`state` varchar(80) NOT NULL DEFAULT 'Pará',
	`phone` varchar(80) NOT NULL DEFAULT '(091) 3556–1397',
	`inepCode` varchar(40) NOT NULL DEFAULT '15178137',
	`authorizationAct` varchar(240) NOT NULL DEFAULT 'Res. nº 267 de 26/05/2024–CEE/PA',
	`logoData` longtext,
	`signatureData` longtext,
	`signerName` varchar(240) NOT NULL DEFAULT '',
	`signerRole` varchar(160) NOT NULL DEFAULT '',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `institutions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `schoolClasses` (
	`id` int AUTO_INCREMENT NOT NULL,
	`institutionId` int NOT NULL DEFAULT 1,
	`schoolYear` varchar(8) NOT NULL,
	`grade` varchar(80) NOT NULL,
	`name` varchar(100) NOT NULL,
	`shift` enum('MANHÃ','TARDE','NOITE','INTEGRAL') NOT NULL,
	`active` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `schoolClasses_id` PRIMARY KEY(`id`),
	CONSTRAINT `classes_institution_year_name_uq` UNIQUE(`institutionId`,`schoolYear`,`name`)
);
--> statement-breakpoint
CREATE TABLE `students` (
	`id` int AUTO_INCREMENT NOT NULL,
	`institutionId` int NOT NULL DEFAULT 1,
	`fullName` varchar(240) NOT NULL,
	`birthDate` date NOT NULL,
	`motherName` varchar(240) NOT NULL,
	`fatherName` varchar(240),
	`guardianName` varchar(240),
	`enrollmentNumber` varchar(80) NOT NULL,
	`schoolYear` varchar(8) NOT NULL,
	`grade` varchar(80) NOT NULL,
	`className` varchar(100) NOT NULL,
	`shift` enum('MANHÃ','TARDE','NOITE','INTEGRAL') NOT NULL,
	`modality` varchar(120) NOT NULL DEFAULT 'Ensino Médio',
	`enrollmentStatus` enum('ATIVA','INATIVA','TRANSFERIDA','CONCLUÍDA') NOT NULL DEFAULT 'ATIVA',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `students_id` PRIMARY KEY(`id`),
	CONSTRAINT `students_institution_enrollment_year_uq` UNIQUE(`institutionId`,`enrollmentNumber`,`schoolYear`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','secretaria','consulta') NOT NULL DEFAULT 'user';--> statement-breakpoint
ALTER TABLE `users` ADD `institutionId` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `auditLogs` ADD CONSTRAINT `auditLogs_institutionId_institutions_id_fk` FOREIGN KEY (`institutionId`) REFERENCES `institutions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `auditLogs` ADD CONSTRAINT `auditLogs_actorId_users_id_fk` FOREIGN KEY (`actorId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `declarations` ADD CONSTRAINT `declarations_institutionId_institutions_id_fk` FOREIGN KEY (`institutionId`) REFERENCES `institutions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `declarations` ADD CONSTRAINT `declarations_studentId_students_id_fk` FOREIGN KEY (`studentId`) REFERENCES `students`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `declarations` ADD CONSTRAINT `declarations_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `documentTemplates` ADD CONSTRAINT `documentTemplates_institutionId_institutions_id_fk` FOREIGN KEY (`institutionId`) REFERENCES `institutions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `documentTemplates` ADD CONSTRAINT `documentTemplates_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `schoolClasses` ADD CONSTRAINT `schoolClasses_institutionId_institutions_id_fk` FOREIGN KEY (`institutionId`) REFERENCES `institutions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `students` ADD CONSTRAINT `students_institutionId_institutions_id_fk` FOREIGN KEY (`institutionId`) REFERENCES `institutions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `students` ADD CONSTRAINT `students_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `students_institution_name_birth_idx` ON `students` (`institutionId`,`fullName`,`birthDate`);