INSERT INTO `institutions` (`id`, `name`) VALUES (1, 'COLÉGIO ESTADUAL DE ENSINO MÉDIO ROSA ALVAREZ REBELO') ON DUPLICATE KEY UPDATE `id` = `id`;--> statement-breakpoint
ALTER TABLE `users` ADD CONSTRAINT `users_institutionId_institutions_id_fk` FOREIGN KEY (`institutionId`) REFERENCES `institutions`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `users_institution_id_idx` ON `users` (`institutionId`);
