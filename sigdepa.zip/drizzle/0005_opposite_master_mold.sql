CREATE TABLE IF NOT EXISTS `authLoginAttempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bucket` varchar(64) NOT NULL,
	`count` int NOT NULL DEFAULT 0,
	`windowStartedAt` timestamp NOT NULL,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `authLoginAttempts_id` PRIMARY KEY(`id`),
	CONSTRAINT `auth_login_attempts_bucket_uq` UNIQUE(`bucket`)
);
--> statement-breakpoint
ALTER TABLE `schoolClasses` ADD INDEX `schoolClasses_institution_id_idx` (`institutionId`);
--> statement-breakpoint
ALTER TABLE `schoolClasses` ADD CONSTRAINT `classes_institution_year_grade_name_shift_tmp_uq` UNIQUE(`institutionId`,`schoolYear`,`grade`,`name`,`shift`);
--> statement-breakpoint
ALTER TABLE `schoolClasses` DROP INDEX `classes_institution_year_name_uq`;
--> statement-breakpoint
ALTER TABLE `schoolClasses` ADD CONSTRAINT `classes_institution_year_name_uq` UNIQUE(`institutionId`,`schoolYear`,`grade`,`name`,`shift`);
--> statement-breakpoint
ALTER TABLE `schoolClasses` DROP INDEX `classes_institution_year_grade_name_shift_tmp_uq`;
