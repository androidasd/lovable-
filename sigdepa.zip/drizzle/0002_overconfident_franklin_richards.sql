CREATE TABLE `enrollments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`institutionId` int NOT NULL DEFAULT 1,
	`studentId` int NOT NULL,
	`classId` int NOT NULL,
	`enrollmentNumber` varchar(80) NOT NULL,
	`schoolYear` varchar(8) NOT NULL,
	`modality` varchar(120) NOT NULL DEFAULT 'Ensino Médio',
	`status` enum('ATIVA','INATIVA','TRANSFERIDA','CONCLUÍDA') NOT NULL DEFAULT 'ATIVA',
	`createdBy` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `enrollments_id` PRIMARY KEY(`id`),
	CONSTRAINT `enrollments_institution_student_year_uq` UNIQUE(`institutionId`,`studentId`,`schoolYear`),
	CONSTRAINT `enrollments_institution_number_year_uq` UNIQUE(`institutionId`,`enrollmentNumber`,`schoolYear`)
);
--> statement-breakpoint
ALTER TABLE `enrollments` ADD CONSTRAINT `enrollments_institutionId_institutions_id_fk` FOREIGN KEY (`institutionId`) REFERENCES `institutions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `enrollments` ADD CONSTRAINT `enrollments_studentId_students_id_fk` FOREIGN KEY (`studentId`) REFERENCES `students`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `enrollments` ADD CONSTRAINT `enrollments_classId_schoolClasses_id_fk` FOREIGN KEY (`classId`) REFERENCES `schoolClasses`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `enrollments` ADD CONSTRAINT `enrollments_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `enrollments_student_idx` ON `enrollments` (`studentId`);--> statement-breakpoint
CREATE INDEX `enrollments_class_idx` ON `enrollments` (`classId`);