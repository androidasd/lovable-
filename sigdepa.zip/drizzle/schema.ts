import {
  boolean,
  date,
  int,
  index,
  json,
  longtext,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const institutions = mysqlTable("institutions", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 240 }).notNull(),
  government: varchar("government", { length: 240 }).notNull().default("GOVERNO DO ESTADO DO PARÁ"),
  secretary: varchar("secretary", { length: 240 }).notNull().default("SECRETARIA EXECUTIVA DE EDUCAÇÃO"),
  regionalOffice: varchar("regionalOffice", { length: 240 }).notNull().default("10ª UNIDADE REGIONAL DE EDUCAÇÃO"),
  address: varchar("address", { length: 320 }).notNull().default("Rua Sete de Setembro, nº 576 – bairro: Centro"),
  municipality: varchar("municipality", { length: 160 }).notNull().default("Senador José Porfírio"),
  state: varchar("state", { length: 80 }).notNull().default("Pará"),
  phone: varchar("phone", { length: 80 }).notNull().default("(091) 3556–1397"),
  inepCode: varchar("inepCode", { length: 40 }).notNull().default("15178137"),
  authorizationAct: varchar("authorizationAct", { length: 240 }).notNull().default("Res. nº 267 de 26/05/2024–CEE/PA"),
  logoData: longtext("logoData"),
  signatureData: longtext("signatureData"),
  signerName: varchar("signerName", { length: 240 }).notNull().default(""),
  signerRole: varchar("signerRole", { length: 160 }).notNull().default(""),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin", "secretaria", "consulta"]).default("user").notNull(),
  sessionVersion: int("sessionVersion").notNull().default(0),
  institutionId: int("institutionId").notNull().default(1).references(() => institutions.id, { onDelete: "restrict" }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
}, (table) => ({ institutionIndex: index("users_institution_id_idx").on(table.institutionId) }));

export const localCredentials = mysqlTable("localCredentials", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  emailNormalized: varchar("emailNormalized", { length: 320 }).notNull(),
  passwordHash: varchar("passwordHash", { length: 255 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userUnique: uniqueIndex("local_credentials_user_uq").on(table.userId),
  emailUnique: uniqueIndex("local_credentials_email_uq").on(table.emailNormalized),
}));

export const authBootstrap = mysqlTable("authBootstrap", {
  id: int("id").primaryKey(),
  completed: boolean("completed").notNull().default(false),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const authLoginAttempts = mysqlTable("authLoginAttempts", {
  id: int("id").autoincrement().primaryKey(),
  bucket: varchar("bucket", { length: 64 }).notNull(),
  count: int("count").notNull().default(0),
  windowStartedAt: timestamp("windowStartedAt").notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({ bucketUnique: uniqueIndex("auth_login_attempts_bucket_uq").on(table.bucket) }));

export const schoolClasses = mysqlTable("schoolClasses", {
  id: int("id").autoincrement().primaryKey(),
  institutionId: int("institutionId").notNull().default(1).references(() => institutions.id),
  schoolYear: varchar("schoolYear", { length: 8 }).notNull(),
  grade: varchar("grade", { length: 80 }).notNull(),
  name: varchar("name", { length: 100 }).notNull(),
  shift: mysqlEnum("shift", ["MANHÃ", "TARDE", "NOITE", "INTEGRAL"]).notNull(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  institutionIdIndex: index("schoolClasses_institution_id_idx").on(table.institutionId),
  institutionYearClass: uniqueIndex("classes_institution_year_name_uq").on(table.institutionId, table.schoolYear, table.grade, table.name, table.shift),
}));

export const students = mysqlTable("students", {
  id: int("id").autoincrement().primaryKey(),
  institutionId: int("institutionId").notNull().default(1).references(() => institutions.id),
  fullName: varchar("fullName", { length: 240 }).notNull(),
  birthDate: date("birthDate", { mode: "string" }).notNull(),
  motherName: varchar("motherName", { length: 240 }).notNull(),
  fatherName: varchar("fatherName", { length: 240 }),
  guardianName: varchar("guardianName", { length: 240 }),
  enrollmentNumber: varchar("enrollmentNumber", { length: 80 }).notNull(),
  schoolYear: varchar("schoolYear", { length: 8 }).notNull(),
  grade: varchar("grade", { length: 80 }).notNull(),
  className: varchar("className", { length: 100 }).notNull(),
  shift: mysqlEnum("shift", ["MANHÃ", "TARDE", "NOITE", "INTEGRAL"]).notNull(),
  modality: varchar("modality", { length: 120 }).notNull().default("Ensino Médio"),
  enrollmentStatus: mysqlEnum("enrollmentStatus", ["ATIVA", "INATIVA", "TRANSFERIDA", "CONCLUÍDA"]).notNull().default("ATIVA"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  enrollmentYear: uniqueIndex("students_institution_enrollment_year_uq").on(table.institutionId, table.enrollmentNumber, table.schoolYear),
  nameIndex: index("students_institution_name_birth_idx").on(table.institutionId, table.fullName, table.birthDate),
}));

export const enrollments = mysqlTable("enrollments", {
  id: int("id").autoincrement().primaryKey(),
  institutionId: int("institutionId").notNull().default(1).references(() => institutions.id),
  studentId: int("studentId").notNull().references(() => students.id),
  classId: int("classId").notNull().references(() => schoolClasses.id),
  enrollmentNumber: varchar("enrollmentNumber", { length: 80 }).notNull(),
  schoolYear: varchar("schoolYear", { length: 8 }).notNull(),
  modality: varchar("modality", { length: 120 }).notNull().default("Ensino Médio"),
  status: mysqlEnum("status", ["ATIVA", "INATIVA", "TRANSFERIDA", "CONCLUÍDA"]).notNull().default("ATIVA"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  studentYearUnique: uniqueIndex("enrollments_institution_student_year_uq").on(table.institutionId, table.studentId, table.schoolYear),
  numberYearUnique: uniqueIndex("enrollments_institution_number_year_uq").on(table.institutionId, table.enrollmentNumber, table.schoolYear),
  studentIndex: index("enrollments_student_idx").on(table.studentId),
  classIndex: index("enrollments_class_idx").on(table.classId),
}));

export const documentTemplates = mysqlTable("documentTemplates", {
  id: int("id").autoincrement().primaryKey(),
  institutionId: int("institutionId").notNull().default(1).references(() => institutions.id),
  name: varchar("name", { length: 160 }).notNull(),
  content: text("content").notNull(),
  version: int("version").notNull().default(1),
  active: boolean("active").notNull().default(true),
  createdBy: int("createdBy").references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  institutionVersion: uniqueIndex("templates_institution_name_version_uq").on(table.institutionId, table.name, table.version),
}));

export const documentSequences = mysqlTable("documentSequences", {
  year: int("year").primaryKey(),
  lastNumber: int("lastNumber").notNull().default(0),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const declarations = mysqlTable("declarations", {
  id: int("id").autoincrement().primaryKey(),
  institutionId: int("institutionId").notNull().default(1).references(() => institutions.id),
  studentId: int("studentId").references(() => students.id, { onDelete: "set null" }),
  documentNumber: varchar("documentNumber", { length: 32 }).notNull(),
  sequenceYear: int("sequenceYear").notNull(),
  sequenceNumber: int("sequenceNumber").notNull(),
  issuedAt: date("issuedAt", { mode: "string" }).notNull(),
  signerName: varchar("signerName", { length: 240 }).notNull(),
  signerRole: varchar("signerRole", { length: 160 }).notNull(),
  snapshot: json("snapshot").$type<Record<string, unknown>>().notNull(),
  templateVersion: int("templateVersion").notNull().default(1),
  status: mysqlEnum("status", ["EMITIDA", "CANCELADA"]).notNull().default("EMITIDA"),
  cancellationReason: text("cancellationReason"),
  createdBy: int("createdBy").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  numberUnique: uniqueIndex("declarations_institution_number_uq").on(table.institutionId, table.documentNumber),
  yearSequenceUnique: uniqueIndex("declarations_institution_year_seq_uq").on(table.institutionId, table.sequenceYear, table.sequenceNumber),
}));

export const auditLogs = mysqlTable("auditLogs", {
  id: int("id").autoincrement().primaryKey(),
  institutionId: int("institutionId").notNull().default(1).references(() => institutions.id),
  actorId: int("actorId").references(() => users.id),
  action: varchar("action", { length: 100 }).notNull(),
  entityType: varchar("entityType", { length: 80 }).notNull(),
  entityId: varchar("entityId", { length: 80 }),
  details: json("details").$type<Record<string, unknown> | null>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type LocalCredential = typeof localCredentials.$inferSelect;
export type Student = typeof students.$inferSelect;
export type Enrollment = typeof enrollments.$inferSelect;
export type Institution = typeof institutions.$inferSelect;
export type Declaration = typeof declarations.$inferSelect;
export type DocumentTemplate = typeof documentTemplates.$inferSelect;
