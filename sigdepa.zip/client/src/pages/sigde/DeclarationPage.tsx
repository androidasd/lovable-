import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Check, CircleAlert, Download, FilePlus2, FileText, Maximize2, Printer, RefreshCw, Search, ShieldCheck, X } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import type { DeclarationSnapshot } from "@/lib/declaration-pdf";
import { downloadPdf, PdfPreview, printPdf } from "./pdf-tools";
import { Button, EmptyState, ErrorBlock, Field, FieldInput, FieldSelect, LoadingBlock, PageTitle, baseTemplate, emptyDeclaration, fileStem, formatDate, type DeclarationFormData, type EmissionSettings, type Shift, type Student } from "./common";

function declarationSnapshot(form: DeclarationFormData, institution: EmissionSettings | null | undefined, templateContent: string, number?: string): DeclarationSnapshot {
  return {
    ...form,
    documentNumber: number,
    templateContent,
    institution: institution ? {
      name: institution.name, government: institution.government, secretary: institution.secretary,
      regionalOffice: institution.regionalOffice, address: institution.address, municipality: institution.municipality,
      state: institution.state, phone: institution.phone, inepCode: institution.inepCode,
      authorizationAct: institution.authorizationAct, logoData: institution.logoData, signatureData: institution.signatureData,
    } : null,
  };
}

export function DeclarationPage() {
  const utils = trpc.useUtils();
  const [form, setForm] = useState<DeclarationFormData>(emptyDeclaration());
  const [studentSearch, setStudentSearch] = useState("");
  const [studentMenu, setStudentMenu] = useState(false);
  const [studentId, setStudentId] = useState<number | null>(null);
  const [manualAfterSelection, setManualAfterSelection] = useState(false);
  const [zoom, setZoom] = useState(0.82);
  const [savedNumber, setSavedNumber] = useState("");
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<"dados" | "documento">("dados");
  const students = trpc.sigde.students.list.useQuery({ status: "ATIVA", search: studentSearch || undefined, limit: 100 });
  const settings = trpc.sigde.settings.forEmission.useQuery();
  const templates = trpc.sigde.templates.activeForEmission.useQuery();
  const year = Number(form.issuedAt.slice(0, 4)) || new Date().getFullYear();
  const nextNumber = trpc.sigde.declarations.nextNumber.useQuery({ year });
  const create = trpc.sigde.declarations.create.useMutation({
    onSuccess: result => {
      setSavedNumber(result.documentNumber);
      toast.success(`Declaração ${result.documentNumber} emitida e salva.`);
      void utils.sigde.dashboard.invalidate();
      void utils.sigde.declarations.list.invalidate();
      void utils.sigde.declarations.nextNumber.invalidate({ year });
      setSaving(false);
    },
    onError: error => { toast.error(error.message); setSaving(false); },
  });
  const activeTemplate = useMemo(() => templates.data?.find(t => t.active) ?? templates.data?.[0], [templates.data]);
  useEffect(() => {
    if (settings.data && !form.signerName) setForm(current => ({
      ...current,
      signerName: settings.data!.signerName || (settings.data!.signatureData ? "" : "Nixon Klauberg Macedo Calado"),
      signerRole: settings.data!.signerRole || (settings.data!.signatureData ? "" : "Diretor do C.E.E.M. Rosa Alvarez Rebelo"),
    }));
  }, [settings.data]);
  useEffect(() => { if (!form.templateId && activeTemplate) setForm(current => ({ ...current, templateId: activeTemplate.id })); }, [activeTemplate]);
  useEffect(() => { setSavedNumber(""); }, [form]);
  const filteredStudents = students.data ?? [];
  const snapshot = declarationSnapshot(form, settings.data, activeTemplate?.content ?? baseTemplate, savedNumber || nextNumber.data?.number);
  const canIssue = (form.fullName.trim().length > 2 && form.birthDate && (form.motherName || form.guardianName) && form.grade && form.className && form.signerName.trim().length > 1);
  const linkedStudentFields = new Set<keyof DeclarationFormData>(["fullName", "birthDate", "motherName", "fatherName", "guardianName", "schoolYear", "grade", "className", "shift", "modality"]);
  const set = <K extends keyof DeclarationFormData>(key: K, value: DeclarationFormData[K]) => {
    if (studentId && linkedStudentFields.has(key)) {
      setStudentId(null); setStudentSearch(""); setStudentMenu(false); setManualAfterSelection(true);
      toast.info("O cadastro foi desvinculado porque os dados do aluno foram alterados. A emissão seguirá como manual.");
    }
    setForm(current => ({ ...current, [key]: value }));
  };
  const pickStudent = (student: Student) => {
    setStudentId(student.id); setStudentSearch(student.fullName); setStudentMenu(false); setSavedNumber(""); setManualAfterSelection(false);
    setForm(current => ({ ...current, fullName: student.fullName, birthDate: student.birthDate, motherName: student.motherName, fatherName: student.fatherName ?? "", guardianName: student.guardianName ?? "", schoolYear: student.schoolYear, grade: student.grade, className: student.className, shift: student.shift, modality: student.modality }));
  };
  const resetForm = () => {
    setStudentId(null); setStudentSearch(""); setSavedNumber(""); setManualAfterSelection(false);
    setForm({ ...emptyDeclaration(), signerName: settings.data?.signerName ?? "", signerRole: settings.data?.signerRole ?? "", templateId: activeTemplate?.id ?? null });
  };
  const createDocument = (event: FormEvent) => {
    event.preventDefault(); if (!canIssue || saving) return;
    setSaving(true);
    create.mutate({ ...form, studentId, fatherName: form.fatherName || null, guardianName: form.guardianName || null, templateId: form.templateId });
  };
  return <div className="sg-page">
    <PageTitle eyebrow="DOCUMENTOS ESCOLARES" title="Emitir declaração" subtitle="Preencha os dados e confira o documento antes de salvar." action={<div className="sg-number-preview"><span>Nº previsto</span><strong>{savedNumber || nextNumber.data?.number || "—"}</strong></div>}/>
    {settings.error && <ErrorBlock message="Não foi possível carregar as configurações institucionais." retry={() => void settings.refetch()}/>}
    <div className="sg-mobile-tabs"><button className={activeTab === "dados" ? "active" : ""} onClick={() => setActiveTab("dados")}>Dados</button><button className={activeTab === "documento" ? "active" : ""} onClick={() => setActiveTab("documento")}>Pré-visualização</button></div>
    <div className="sg-emission-layout">
      <section className={`sg-panel sg-emission-form ${activeTab === "documento" ? "sg-mobile-hidden" : ""}`}>
        <div className="sg-panel-head"><div><span className="sg-eyebrow">PREENCHIMENTO</span><h2>Dados da declaração</h2></div><span className="sg-required-note">* Obrigatório</span></div>
        <form className="sg-form sg-emit-form" onSubmit={createDocument}>
          <div className="sg-form-section-title"><span>01</span> Localizar aluno</div>
          <div className="sg-autocomplete"><Field label="Pesquisar cadastro (opcional)" hint="Selecione um aluno para preencher os campos automaticamente."><div className="sg-search"><Search size={17}/><input value={studentSearch} onFocus={() => setStudentMenu(true)} onChange={e => { setStudentSearch(e.target.value); setStudentId(null); setManualAfterSelection(false); setStudentMenu(true); }} placeholder="Nome ou matrícula" autoComplete="off"/><button type="button" title="Limpar seleção" onClick={() => { setStudentId(null); setStudentSearch(""); setManualAfterSelection(false); setForm({ ...emptyDeclaration(), signerName: settings.data?.signerName ?? "", signerRole: settings.data?.signerRole ?? "", templateId: activeTemplate?.id ?? null }); }}><X size={15}/></button></div></Field>{studentMenu && studentSearch.length > 0 && <div className="sg-autocomplete-menu">{students.isLoading ? <div className="sg-autocomplete-empty">Buscando cadastros...</div> : filteredStudents.length ? filteredStudents.slice(0, 8).map(student => <button type="button" key={student.id} onClick={() => pickStudent(student)}><span className="sg-autocomplete-avatar">{student.fullName.slice(0, 1)}</span><span><strong>{student.fullName}</strong><small>{student.enrollmentNumber} · {student.grade} · {student.className}</small></span></button>) : <div className="sg-autocomplete-empty">Nenhum cadastro ativo encontrado. Preencha os dados manualmente.</div>}<button type="button" className="sg-autocomplete-close" onClick={() => setStudentMenu(false)}>Fechar lista</button></div>}</div>
          {manualAfterSelection && <div className="sg-info-banner"><ShieldCheck size={16}/> Dados alterados; a declaração está desvinculada do cadastro e será emitida como preenchimento manual.</div>}<div className="sg-form-section-title"><span>02</span> Dados do aluno</div>
          <div className="sg-form-grid"><Field label="Nome completo *"><FieldInput value={form.fullName} onChange={e => set("fullName", e.target.value)} required maxLength={240}/></Field><Field label="Data de nascimento *"><FieldInput type="date" value={form.birthDate} onChange={e => set("birthDate", e.target.value)} required/></Field><Field label="Nome da mãe"><FieldInput value={form.motherName} onChange={e => set("motherName", e.target.value)} maxLength={240}/></Field><Field label="Nome do pai (opcional)"><FieldInput value={form.fatherName} onChange={e => set("fatherName", e.target.value)} maxLength={240}/></Field><Field label="Responsável legal (opcional)"><FieldInput value={form.guardianName} onChange={e => set("guardianName", e.target.value)} maxLength={240}/></Field><Field label="Ano letivo *"><FieldInput value={form.schoolYear} onChange={e => set("schoolYear", e.target.value)} required pattern="\d{4}" maxLength={4}/></Field><Field label="Série *"><FieldInput value={form.grade} onChange={e => set("grade", e.target.value)} placeholder="Ex.: 3ª série" required/></Field><Field label="Turma *"><FieldInput value={form.className} onChange={e => set("className", e.target.value)} placeholder="Ex.: M3NNG03" required/></Field><Field label="Turno *"><FieldSelect value={form.shift} onChange={e => set("shift", e.target.value as Shift)}>{["MANHÃ", "TARDE", "NOITE", "INTEGRAL"].map(s => <option key={s}>{s}</option>)}</FieldSelect></Field></div>
          <div className="sg-form-section-title"><span>03</span> Dados do documento</div>
          <div className="sg-form-grid"><Field label="Data de emissão *"><FieldInput type="date" value={form.issuedAt} onChange={e => set("issuedAt", e.target.value)} required/></Field><Field label="Número da declaração"><FieldInput value={savedNumber || nextNumber.data?.number || "Atribuído ao salvar"} readOnly className="sg-readonly"/></Field><Field label="Responsável pela assinatura *"><FieldInput value={form.signerName} onChange={e => set("signerName", e.target.value)} required maxLength={240}/></Field><Field label="Cargo do responsável"><FieldInput value={form.signerRole} onChange={e => set("signerRole", e.target.value)} maxLength={160}/></Field><Field label="Modelo do documento" className="sg-field-full"><FieldSelect value={form.templateId ?? ""} onChange={e => set("templateId", e.target.value ? Number(e.target.value) : null)}>{templates.data?.length ? templates.data.filter(t => t.active).map(t => <option key={t.id} value={t.id}>{t.name} · v{t.version}</option>) : <option value="">Modelo institucional padrão</option>}</FieldSelect></Field></div>
          {!form.motherName && !form.guardianName && <div className="sg-warning-inline"><CircleAlert size={16}/> Informe o nome da mãe ou do responsável para compor a filiação.</div>}
          <div className="sg-form-footer"><Button type="button" variant="secondary" onClick={resetForm}><FilePlus2 size={16}/> Nova declaração</Button><Button type="submit" disabled={!canIssue || saving}>{saving ? <><span className="sg-spinner"/> Salvando...</> : <><Check size={17}/> Salvar declaração</>}</Button></div>
          {savedNumber && <div className="sg-success-inline"><Check size={17}/><div><strong>Declaração {savedNumber} salva.</strong><small>Os dados usados foram preservados no histórico.</small></div></div>}
        </form>
      </section>
      <section className={`sg-panel sg-preview-panel ${activeTab === "dados" ? "sg-mobile-hidden" : ""}`}>
        <div className="sg-panel-head"><div><span className="sg-eyebrow">DOCUMENTO A4</span><h2>Pré-visualização</h2></div><div className="sg-zoom-controls"><button title="Diminuir zoom" onClick={() => setZoom(z => Math.max(.55, Math.round((z - .1) * 100) / 100))}>−</button><span>{Math.round(zoom * 100)}%</span><button title="Aumentar zoom" onClick={() => setZoom(z => Math.min(1.1, Math.round((z + .1) * 100) / 100))}>+</button><button title="Ajustar à página" onClick={() => setZoom(.82)}><RefreshCw size={14}/></button></div></div>
        <div className="sg-preview-meta"><span><i className="sg-live-dot"/> Atualização em tempo real</span><span>A4 · Retrato</span></div>
        <div className="sg-preview-document"><PdfPreview snapshot={snapshot} zoom={zoom}/></div>
        <div className="sg-preview-actions"><Button variant="ghost" onClick={() => { const target = document.querySelector(".sg-preview-document"); if (target?.requestFullscreen) void target.requestFullscreen(); }}><Maximize2 size={16}/> Tela cheia</Button><Button variant="secondary" disabled={!savedNumber} onClick={() => void printPdf(snapshot)}><Printer size={16}/> Imprimir</Button><Button variant="secondary" disabled={!savedNumber} onClick={() => void downloadPdf(snapshot, `DECLARACAO_ESCOLARIDADE_${fileStem(form.fullName)}_${year}.pdf`)}><Download size={16}/> Baixar PDF</Button></div>
        <p className="sg-preview-disclaimer">A numeração exibida é uma previsão. Salve a declaração para fixar o número e habilitar impressão e download do PDF oficial.</p>
      </section>
    </div>
  </div>;
}
