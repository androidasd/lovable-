import { useState, type FormEvent } from "react";
import { Activity, KeyRound, ShieldCheck, Users } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Button, EmptyState, ErrorBlock, Field, FieldInput, FieldSelect, LoadingBlock, Modal, PageTitle, formatDate, type UserRole } from "./common";

export function UsersPage() {
  const utils = trpc.useUtils();
  const me = trpc.auth.me.useQuery(undefined, { retry: false });
  const usersQuery = trpc.sigde.users.list.useQuery(undefined, { enabled: me.data?.role === "admin" });
  const auditQuery = trpc.sigde.audit.list.useQuery({ limit: 100 }, { enabled: me.data?.role === "admin" });
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [role, setRole] = useState<UserRole>("secretaria");
  const [resetUserId, setResetUserId] = useState<number | null>(null);
  const [resetPassword, setResetPassword] = useState("");
  const [resetConfirm, setResetConfirm] = useState("");
  const update = trpc.sigde.users.setRole.useMutation({
    onSuccess: () => {
      toast.success("Permissão atualizada.");
      void utils.sigde.users.list.invalidate();
      void utils.sigde.audit.list.invalidate();
    },
    onError: error => toast.error(error.message),
  });
  const create = trpc.sigde.users.createAccount.useMutation({
    onSuccess: () => {
      toast.success("Conta criada. Compartilhe as credenciais com o usuário por um canal seguro.");
      setName(""); setEmail(""); setPassword(""); setConfirmPassword(""); setRole("secretaria");
      void utils.sigde.users.list.invalidate();
      void utils.sigde.audit.list.invalidate();
    },
    onError: error => toast.error(error.message),
  });
  const setPasswordMutation = trpc.sigde.users.setPassword.useMutation({
    onSuccess: () => {
      toast.success("Senha definida. Compartilhe a nova credencial por um canal seguro.");
      setResetUserId(null); setResetPassword(""); setResetConfirm("");
      void utils.sigde.users.list.invalidate();
      void utils.sigde.audit.list.invalidate();
    },
    onError: error => toast.error(error.message),
  });
  const resetTarget = usersQuery.data?.find(user => user.id === resetUserId);

  const submitCreate = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (password !== confirmPassword) { toast.error("As senhas não coincidem."); return; }
    create.mutate({ name, email, password, role });
  };
  const submitReset = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (resetUserId === null) return;
    if (resetPassword !== resetConfirm) { toast.error("As senhas não coincidem."); return; }
    setPasswordMutation.mutate({ id: resetUserId, password: resetPassword });
  };

  if (me.data?.role !== "admin") {
    return <div className="sg-page"><PageTitle eyebrow="ACESSO RESTRITO" title="Usuários e permissões"/><div className="sg-info-banner"><ShieldCheck size={18}/> Esta área é exclusiva do perfil Administrador.</div></div>;
  }

  return <div className="sg-page">
    <PageTitle eyebrow="ADMINISTRAÇÃO DE ACESSO" title="Usuários e permissões" subtitle="Crie contas locais, atribua o perfil mínimo necessário e redefina senhas quando preciso."/>
    <div className="sg-info-banner"><ShieldCheck size={17}/> O SIGDE usa e-mail e senha. As senhas são armazenadas como hashes; o sistema não envia credenciais nem links por e-mail.</div>
    <section className="sg-panel sg-list-panel">
      <div className="sg-panel-head"><div><span className="sg-eyebrow">NOVA CONTA LOCAL</span><h2>Criar usuário</h2></div><span className="sg-panel-tag"><Users size={15}/> Acesso individual</span></div>
      <form className="sg-admin-account-form" onSubmit={submitCreate}>
        <Field label="Nome"><FieldInput autoComplete="name" minLength={2} maxLength={240} required value={name} onChange={event => setName(event.target.value)}/></Field>
        <Field label="E-mail"><FieldInput type="email" autoComplete="email" maxLength={320} required value={email} onChange={event => setEmail(event.target.value)}/></Field>
        <Field label="Senha inicial" hint="Mínimo de 12 caracteres."><FieldInput type="password" autoComplete="new-password" minLength={12} maxLength={128} required value={password} onChange={event => setPassword(event.target.value)}/></Field>
        <Field label="Confirme a senha"><FieldInput type="password" autoComplete="new-password" minLength={12} maxLength={128} required value={confirmPassword} onChange={event => setConfirmPassword(event.target.value)}/></Field>
        <Field label="Perfil"><FieldSelect value={role} onChange={event => setRole(event.target.value as UserRole)}><option value="secretaria">Secretaria</option><option value="consulta">Consulta</option><option value="admin">Administrador</option><option value="user">Aguardando autorização</option></FieldSelect></Field>
        <div className="sg-admin-account-submit"><Button type="submit" disabled={create.isPending}>{create.isPending ? "Criando..." : "Criar conta"}</Button></div>
      </form>
    </section>
    <section className="sg-panel sg-list-panel">
      <div className="sg-panel-head"><div><span className="sg-eyebrow">CONTAS LOCAIS</span><h2>Usuários da escola</h2></div><span className="sg-panel-tag"><Users size={15}/>{usersQuery.data?.length ?? 0} usuário(s)</span></div>
      {usersQuery.isLoading ? <LoadingBlock/> : usersQuery.error ? <ErrorBlock message="Não foi possível consultar os usuários." retry={() => void usersQuery.refetch()}/> : usersQuery.data?.length ? <div className="sg-table-wrap"><table className="sg-table"><thead><tr><th>Usuário</th><th>Senha local</th><th>Último acesso</th><th>Perfil</th><th>Ações</th></tr></thead><tbody>{usersQuery.data.map(user => <tr key={user.id}>
        <td><strong>{user.name || "Conta institucional"}</strong><small>{user.email || "E-mail não informado"}</small></td>
        <td><span className={`sg-password-badge ${user.hasPassword ? "is-ready" : "is-missing"}`}>{user.hasPassword ? "Configurada" : "Não configurada"}</span></td>
        <td>{formatDate(user.lastSignedIn)}</td>
        <td><select className="sg-role-select" value={user.role} disabled={update.isPending} onChange={event => update.mutate({ id: user.id, role: event.target.value as Exclude<UserRole, "user"> })}>
          {user.role === "user" && <option value="user" disabled>Aguardando autorização</option>}
          <option value="admin">Administrador</option><option value="secretaria">Secretaria</option><option value="consulta">Consulta</option>
        </select></td>
        <td><button className="sg-text-action" type="button" disabled={user.id === me.data?.id} onClick={() => setResetUserId(user.id)}><KeyRound size={14}/>{user.id === me.data?.id ? "Use Minha senha" : user.hasPassword ? "Redefinir senha" : "Definir senha"}</button></td>
      </tr>)}</tbody></table></div> : <EmptyState icon={Users} title="Nenhum usuário registrado" detail="Crie a primeira conta local usando o formulário acima."/>}
    </section>
    <section className="sg-panel sg-list-panel">
      <div className="sg-panel-head"><div><span className="sg-eyebrow">TRILHA DE AUDITORIA</span><h2>Ações recentes</h2></div><span className="sg-panel-tag"><Activity size={15}/> Registro institucional</span></div>
      {auditQuery.isLoading ? <LoadingBlock/> : auditQuery.error ? <ErrorBlock message="Não foi possível carregar a auditoria." retry={() => void auditQuery.refetch()}/> : auditQuery.data?.length ? <div className="sg-table-wrap"><table className="sg-table"><thead><tr><th>Data</th><th>Usuário</th><th>Ação</th><th>Registro</th></tr></thead><tbody>{auditQuery.data.map(row => <tr key={row.id}><td>{formatDate(row.createdAt)}</td><td>{row.actorName || "Conta institucional"}</td><td>{row.action.replaceAll(".", " · ")}</td><td>{row.entityType}{row.entityId ? ` #${row.entityId}` : ""}</td></tr>)}</tbody></table></div> : <EmptyState icon={Activity} title="Auditoria sem eventos" detail="As ações relevantes serão registradas conforme o uso do sistema."/>}
    </section>
    {resetTarget && <Modal title={`${resetTarget.hasPassword ? "Redefinir" : "Definir"} senha`} onClose={() => { setResetUserId(null); setResetPassword(""); setResetConfirm(""); }}>
      <form className="sg-password-form" onSubmit={submitReset}>
        <p>Conta: <strong>{resetTarget.name || resetTarget.email}</strong></p>
        <Field label="Nova senha" hint="Mínimo de 12 caracteres."><FieldInput type="password" autoComplete="new-password" minLength={12} maxLength={128} required value={resetPassword} onChange={event => setResetPassword(event.target.value)}/></Field>
        <Field label="Confirme a senha"><FieldInput type="password" autoComplete="new-password" minLength={12} maxLength={128} required value={resetConfirm} onChange={event => setResetConfirm(event.target.value)}/></Field>
        <div className="sg-password-actions"><Button type="button" variant="secondary" onClick={() => setResetUserId(null)}>Cancelar</Button><Button type="submit" disabled={setPasswordMutation.isPending}>{setPasswordMutation.isPending ? "Salvando..." : "Salvar senha"}</Button></div>
      </form>
    </Modal>}
  </div>;
}
