import { useState } from "react";
import { Activity, ArrowDownToLine, Download, Filter, FileText, Maximize2, Printer, RefreshCw, Search, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import type { DeclarationSnapshot } from "@/lib/declaration-pdf";
import { downloadPdf, PdfPreview, printPdf } from "./pdf-tools";
import { Button, EmptyState, ErrorBlock, LoadingBlock, PageTitle, StatusPill, csvCell, fileStem, formatDate, humanStatus, type SavedDeclaration } from "./common";

function storedSnapshot(record: SavedDeclaration): DeclarationSnapshot {
  return { ...(record.snapshot as unknown as DeclarationSnapshot), documentNumber: record.documentNumber, status: record.status };
}

export function DeclarationsPage() {
  const utils = trpc.useUtils();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<"" | "EMITIDA" | "CANCELADA">("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [selected, setSelected] = useState<number | null>(null);
  const [zoom, setZoom] = useState(.82);
  const [activeTab, setActiveTab] = useState<"lista" | "documento">("lista");
  const query = trpc.sigde.declarations.list.useQuery({ search: search || undefined, status: status || undefined, from: from || undefined, to: to || undefined });
  const detail = trpc.sigde.declarations.get.useQuery({ id: selected ?? 0 }, { enabled: !!selected });
  const me = trpc.auth.me.useQuery(undefined, { retry: false });
  const canCancel = me.data?.role === "admin" || me.data?.role === "secretaria";
  const cancel = trpc.sigde.declarations.cancel.useMutation({ onSuccess: () => { toast.success("Declaração cancelada com justificativa."); void query.refetch(); void utils.sigde.dashboard.invalidate(); }, onError: e => toast.error(e.message) });
  const exportCsv = () => {
    const rows = query.data ?? [];
    const csv = ["Número;Aluno;Série;Emissão;Responsável;Status", ...rows.map(r => [r.documentNumber, r.fullName || "Cadastro manual", r.grade || "", formatDate(r.issuedAt), r.issuerName || "", humanStatus(r.status)].map(csvCell).join(";"))].join("\r\n");
    const blob = new Blob(["\ufeff", csv], { type: "text/csv;charset=utf-8" }); const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href = url; a.download = "historico_declaracoes.csv"; a.click(); URL.revokeObjectURL(url);
  };
  const record = detail.data;
  const snapshot = record ? storedSnapshot(record) : null;
  return <div className="sg-page">
    <PageTitle eyebrow="CONTROLE DOCUMENTAL" title="Declarações emitidas" subtitle="Consulte o histórico e gere novamente a segunda via de documentos salvos." action={<Button variant="secondary" onClick={exportCsv} disabled={!query.data?.length}><ArrowDownToLine size={17}/> Exportar relatório</Button>}/>
    <div className="sg-mobile-tabs"><button className={activeTab === "lista" ? "active" : ""} onClick={() => setActiveTab("lista")}>Histórico</button><button className={activeTab === "documento" ? "active" : ""} onClick={() => setActiveTab("documento")} disabled={!selected}>Documento</button></div>
    <section className={`sg-panel sg-list-panel ${activeTab === "documento" ? "sg-mobile-hidden" : ""}`}><div className="sg-list-toolbar"><div className="sg-search"><Search size={17}/><input placeholder="Pesquisar por aluno ou número" value={search} onChange={e => setSearch(e.target.value)}/></div><div className="sg-filter-group"><Filter size={15}/><label>De <input type="date" value={from} onChange={e => setFrom(e.target.value)}/></label><label>Até <input type="date" value={to} onChange={e => setTo(e.target.value)}/></label><select value={status} onChange={e => setStatus(e.target.value as typeof status)}><option value="">Todos os status</option><option value="EMITIDA">Emitida</option><option value="CANCELADA">Cancelada</option></select></div></div>
      {query.isLoading ? <LoadingBlock label="Carregando histórico"/> : query.error ? <ErrorBlock message="Não foi possível consultar as declarações." retry={() => void query.refetch()}/> : query.data?.length ? <div className="sg-table-wrap"><table className="sg-table"><thead><tr><th>Nº do documento</th><th>Aluno</th><th>Série</th><th>Emissão</th><th>Responsável</th><th>Status</th><th>Ações</th></tr></thead><tbody>{query.data.map(row => <tr key={row.id}><td className="sg-code">{row.documentNumber}</td><td><strong>{row.fullName || "Cadastro manual"}</strong><small>{row.grade || "Declaração avulsa"}</small></td><td>{row.grade || "—"}</td><td>{formatDate(row.issuedAt)}</td><td>{row.issuerName || "—"}</td><td><StatusPill status={row.status}/></td><td><div className="sg-row-actions"><button onClick={() => { setSelected(row.id); setActiveTab("documento"); }}>Visualizar</button>{canCancel && row.status === "EMITIDA" && <button className="sg-row-danger" onClick={() => { const reason = window.prompt(`Justificativa para cancelar ${row.documentNumber}:`); if (reason?.trim()) cancel.mutate({ id: row.id, reason }); }}>Cancelar</button>}</div></td></tr>)}</tbody></table></div> : <EmptyState icon={FileText} title="Nenhuma declaração encontrada" detail="As declarações salvas serão listadas aqui com seus dados de emissão preservados."/>}
    </section>
    {selected && <section className={`sg-panel sg-history-preview ${activeTab === "lista" ? "sg-mobile-hidden" : ""}`}>
      <div className="sg-panel-head"><div><span className="sg-eyebrow">SEGUNDA VIA</span><h2>{record?.documentNumber ?? "Declaração"}</h2></div><div className="sg-zoom-controls"><button onClick={() => setZoom(z => Math.max(.55, Math.round((z - .1) * 100) / 100))}>−</button><span>{Math.round(zoom * 100)}%</span><button onClick={() => setZoom(z => Math.min(1.1, Math.round((z + .1) * 100) / 100))}>+</button><button onClick={() => setZoom(.82)} title="Ajustar"><RefreshCw size={14}/></button></div></div>
      {detail.isLoading ? <LoadingBlock/> : detail.error ? <ErrorBlock message="Não foi possível abrir o documento." retry={() => void detail.refetch()}/> : snapshot ? <>
        <div className="sg-preview-document sg-history-document"><PdfPreview snapshot={snapshot} zoom={zoom}/></div>
        {record?.status === "CANCELADA" && <div className="sg-cancelled-banner" role="alert"><Activity size={17}/> Documento cancelado. Qualquer segunda via está marcada como “CANCELADA — SEM VALIDADE”.</div>}
        <div className="sg-preview-actions"><Button variant="ghost" onClick={() => { const target = document.querySelector(".sg-preview-document"); if (target?.requestFullscreen) void target.requestFullscreen(); }}><Maximize2 size={16}/> Tela cheia</Button><Button variant="secondary" onClick={() => void printPdf(snapshot)}><Printer size={16}/> Imprimir novamente</Button><Button onClick={() => void downloadPdf(snapshot, `DECLARACAO_ESCOLARIDADE_${fileStem(snapshot.fullName)}_${record?.sequenceYear}.pdf`)}><Download size={16}/> Baixar PDF novamente</Button></div>
        <div className="sg-info-banner sg-snapshot-note"><ShieldCheck size={16}/> Esta segunda via utiliza o snapshot gravado na emissão original.</div>
      </> : null}
    </section>}
  </div>;
}
