import { useState, type FormEvent, type ReactNode } from "react";
import { Link } from "wouter";
import { ArrowRight, BookOpenText, FilePlus2, FileText, KeyRound, LayoutDashboard, LogOut, Menu, ShieldCheck, Users, X, Settings } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Button, humanRole, navItems, type UserRole } from "./common";

export function AppShell({ children, user, onLogout, role, path, setPath }: { children: ReactNode; user: { name?: string | null; email?: string | null } | null; onLogout: () => void; role: UserRole; path: string; setPath: (path: string) => void }) {
  const [open, setOpen] = useState(false);
  const visible = role === "user"
    ? navItems.filter(item => item.href === "/minha-senha")
    : navItems.filter(item => item.href !== "/minha-senha" && !( ["/modelos", "/configuracoes", "/usuarios"].includes(item.href) && role !== "admin"));
  return <div className="sg-app-shell">
    {open && <button className="sg-mobile-scrim" aria-label="Fechar menu" onClick={() => setOpen(false)}/>}
    <aside className={`sg-sidebar ${open ? "sg-sidebar-open" : ""}`}>
      <div className="sg-brand"><div className="sg-brand-mark"><img src="/assets/logo-governo-para.jpg" alt="Brasão do Governo do Pará"/></div><div><strong>SIGDE</strong><small>GESTÃO ESCOLAR</small></div><button className="sg-mobile-close" onClick={() => setOpen(false)} aria-label="Fechar menu"><X size={18}/></button></div>
      <div className="sg-school-chip"><span className="sg-school-dot"/><div><strong>Rosa Alvarez Rebelo</strong><small>Senador José Porfírio · PA</small></div></div>
      <div className="sg-nav-label">MENU PRINCIPAL</div>
      <nav className="sg-nav">{visible.map(({ href, label, icon: Icon }) => {
        const active = href === "/" ? path === "/" : path === href || (href === "/declaracoes" && path.startsWith("/declaracoes") && path !== "/declaracoes/nova");
        return <Link key={href} href={href} className={`sg-nav-item ${active ? "sg-nav-active" : ""}`} onClick={() => setOpen(false)}><Icon size={18}/><span>{label}</span>{active && <i/>}</Link>;
      })}</nav>
      <div className="sg-sidebar-foot"><div className="sg-security-card"><ShieldCheck size={17}/><div><strong>Acesso protegido</strong><small>Dados escolares confidenciais</small></div></div><div className="sg-version">SIGDE · Ambiente institucional</div></div>
    </aside>
    <main className="sg-main">
      <header className="sg-topbar"><button className="sg-menu-toggle" onClick={() => setOpen(true)} aria-label="Abrir menu"><Menu size={20}/></button><div className="sg-breadcrumb"><span>Secretaria escolar</span><i>/</i><strong>{navItems.find(n => n.href === path)?.label ?? (path === "/declaracoes/nova" ? "Emitir declaração" : path === "/minha-senha" ? "Minha senha" : "SIGDE")}</strong></div><div className="sg-top-actions"><span className="sg-env"><i/> Acesso institucional</span><div className="sg-user-menu"><div className="sg-avatar">{(user?.name?.trim()?.[0] || user?.email?.[0] || "U").toLocaleUpperCase("pt-BR")}</div><div className="sg-user-meta"><strong>{user?.name || user?.email || "Usuário"}</strong><small>{humanRole(role)}</small></div><button className="sg-logout" title="Alterar senha" aria-label="Alterar senha" onClick={() => setPath("/minha-senha")}><KeyRound size={17}/></button><button className="sg-logout" title="Sair" aria-label="Sair" onClick={onLogout}><LogOut size={17}/></button></div></div></header>
      <div className="sg-content">{children}</div>
      <footer className="sg-footer"><span>SIGDE · Sistema Integrado de Gestão de Declarações Escolares</span><span>Secretaria escolar · {new Date().getFullYear()}</span></footer>
    </main>
  </div>;
}

export function LoginScreen() {
  const utils = trpc.useUtils();
  const status = trpc.auth.bootstrapStatus.useQuery(undefined, { retry: false });
  const [showBootstrap, setShowBootstrap] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [token, setToken] = useState("");
  const login = trpc.auth.login.useMutation({
    onSuccess: async () => { await utils.auth.me.invalidate(); },
    onError: error => toast.error(error.message),
  });
  const bootstrap = trpc.auth.bootstrap.useMutation({
    onSuccess: async () => { toast.success("Administrador configurado. Você já está conectado."); await utils.auth.me.invalidate(); },
    onError: error => toast.error(error.message),
  });
  const busy = login.isPending || bootstrap.isPending;
  const setupRequired = Boolean(status.data?.needsSetup);

  const submitLogin = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    login.mutate({ email, password });
  };
  const submitBootstrap = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (password !== confirmPassword) { toast.error("As senhas não coincidem."); return; }
    bootstrap.mutate({ token, name, email, password });
  };

  return <main className="sg-login">
    <div className="sg-login-visual"><div className="sg-login-mark"><img src="/assets/logo-governo-para.jpg" alt="Governo do Estado do Pará"/></div><div className="sg-login-copy"><span className="sg-eyebrow">GESTÃO ESCOLAR · PARÁ</span><h1>Documentos corretos.<br/><em>Secretaria mais ágil.</em></h1><p>Emita e acompanhe declarações de escolaridade em um ambiente institucional seguro.</p></div><div className="sg-login-bottom">Colégio Estadual de Ensino Médio<br/><strong>Rosa Alvarez Rebelo</strong></div></div>
    <div className="sg-login-panel"><div className="sg-login-card"><div className="sg-brand-symbol">S</div><span className="sg-eyebrow">ACESSO AO SISTEMA</span>
      {status.isLoading ? <><h2>Verificando acesso</h2><div className="sg-loading"><span className="sg-spinner"/><span>Consultando configuração segura...</span></div></> : status.error ? <><h2>Acesso indisponível</h2><p>Não foi possível verificar o estado da autenticação. Tente novamente em instantes.</p><button className="sg-btn sg-btn-secondary" onClick={() => void status.refetch()}>Tentar novamente</button></> : setupRequired && showBootstrap ? <>
        <h2>Configuração inicial</h2><p>O primeiro Administrador define suas credenciais nesta tela. Não há cadastro público.</p>
        {status.data?.tokenConfigured ? <form className="sg-login-form" onSubmit={submitBootstrap}>
          <label className="sg-field"><span>Token temporário de configuração</span><input className="sg-input" type="password" autoComplete="one-time-code" minLength={24} maxLength={256} required value={token} onChange={event => setToken(event.target.value)}/></label>
          <label className="sg-field"><span>Nome do Administrador</span><input className="sg-input" autoComplete="name" minLength={2} maxLength={240} required value={name} onChange={event => setName(event.target.value)}/></label>
          <label className="sg-field"><span>E-mail</span><input className="sg-input" type="email" autoComplete="username" maxLength={320} required value={email} onChange={event => setEmail(event.target.value)}/></label>
          <label className="sg-field"><span>Senha</span><input className="sg-input" type="password" autoComplete="new-password" minLength={12} maxLength={128} required value={password} onChange={event => setPassword(event.target.value)}/><small>Use pelo menos 12 caracteres.</small></label>
          <label className="sg-field"><span>Confirme a senha</span><input className="sg-input" type="password" autoComplete="new-password" minLength={12} maxLength={128} required value={confirmPassword} onChange={event => setConfirmPassword(event.target.value)}/></label>
          <Button type="submit" className="sg-login-button" disabled={busy}>{busy ? <><span className="sg-spinner"/> Configurando...</> : <>Criar primeiro Administrador <ArrowRight size={17}/></>}</Button>
          <div className="sg-auth-note">Após a configuração inicial, remova o segredo temporário das configurações do projeto.</div>
        </form> : <div className="sg-auth-blocked"><ShieldCheck size={18}/><span>O primeiro acesso está bloqueado até que o token de bootstrap seja configurado de forma segura no projeto.</span></div>}
        <button type="button" className="sg-btn sg-btn-secondary sg-login-button" onClick={() => setShowBootstrap(false)}>Voltar ao login</button>
      </> : <>
        <h2>Entre no SIGDE</h2><p>Informe o e-mail e a senha associados à sua conta institucional.</p>
        <form className="sg-login-form" onSubmit={submitLogin}>
          <label className="sg-field"><span>E-mail</span><input className="sg-input" type="email" autoComplete="username" maxLength={320} required value={email} onChange={event => setEmail(event.target.value)}/></label>
          <label className="sg-field"><span>Senha</span><input className="sg-input" type="password" autoComplete="current-password" maxLength={128} required value={password} onChange={event => setPassword(event.target.value)}/></label>
          <Button type="submit" className="sg-login-button" disabled={busy}>{busy ? <><span className="sg-spinner"/> Entrando...</> : <>Entrar com e-mail e senha <ArrowRight size={17}/></>}</Button>
        </form>
        {setupRequired ? <>
          <div className="sg-auth-note">A primeira conta Administradora ainda não foi criada. Para configurar o acesso inicial, use a opção abaixo.</div>
          <button type="button" className="sg-btn sg-btn-secondary sg-login-button" onClick={() => setShowBootstrap(true)}>Configurar primeiro Administrador</button>
        </> : <div className="sg-auth-note">Não consegue entrar? Solicite ao Administrador que crie sua conta ou redefina sua senha.</div>}
      </>}
      <div className="sg-login-secure"><ShieldCheck size={16}/> Acesso autenticado e controlado por perfil</div>
    </div><div className="sg-login-legal">As informações escolares são protegidas e devem ser acessadas apenas por pessoas autorizadas.</div></div>
  </main>;
}
