import { lazy, Suspense } from "react";
import type { DeclarationSnapshot } from "@/lib/declaration-pdf";
import { LoadingBlock } from "./common";

const DeclarationPreview = lazy(() => import("@/lib/declaration-pdf").then(module => ({ default: module.DeclarationPreview })));

export function PdfPreview({ snapshot, zoom }: { snapshot: DeclarationSnapshot; zoom: number }) {
  return <Suspense fallback={<LoadingBlock label="Montando documento"/>}><DeclarationPreview snapshot={snapshot} zoom={zoom}/></Suspense>;
}

export const downloadPdf = async (snapshot: DeclarationSnapshot, filename: string) => (await import("@/lib/declaration-pdf")).downloadDeclaration(snapshot, filename);
export const printPdf = async (snapshot: DeclarationSnapshot) => (await import("@/lib/declaration-pdf")).printDeclaration(snapshot);
