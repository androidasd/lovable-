import { useEffect, useState, type FormEvent } from "react";
import { Check, CircleAlert, FileText, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Button, EmptyState, ErrorBlock, Field, FieldInput, LoadingBlock, PageTitle, baseTemplate, formatDate } from "./common";

export function TemplatesPage() {
  const utils = trpc.useUtils();
  const query = trpc.sigde.templates.list.useQuery();
  const me = trpc.auth.me.useQuery(undefined, { retry: false });
  const canEdit = me.data?.role === "admin";
  const [name, setName] = useState("Declaração de Escolaridade");
  const [content, setContent] = useState(baseTemplate);
  const [saving, setSaving] = useState(false);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  useEffect(() => { if (!selectedId && query.data?.length) { const active = query.data.find(t => t.active) ?? query.data[0]; setSelectedId(active.id); setName(active.name); setContent(active.content); } }, [query.data, selectedId]);
  const save = trpc.sigde.templates.save.useMutation({ onSuccess: result => { toast.success(`Modelo salvo como versão ${result.version}. As declarações anteriores permanecem iguais.`); setSaving(false); setSelectedId(null); void utils.sigde.templates.list.invalidate(); }, onError: e => { toast.error(e.message); setSaving(false); } });
  const active = query.data?.find(t => t.active) ?? query.data?.[0];
  const submit = (e: FormEvent) => { e.preventDefault(); if (!canEdit) return; setSaving(true); save.mutate({ name, content }); };
  return <div className="sg-page"><PageTitle eyebrow="MODELOS DOCUMENTAIS" title="Modelos de documentos" subtitle="Edite o texto-base com controle de versões, sem alterar declarações já emitidas." action={canEdit ? <Button form="sg-template-form" type="submit" disabled={saving}>{saving ? <><span className="sg-spinner"/> Salvando...</> : <><Check size={16}/> Salvar nova versão</>}</Button> : undefined}/>{!canEdit && <div className="sg-info-banner"><ShieldCheck size={17}/> Seu perfil tem acesso de consulta aos modelos.</div>}
    {query.error && <ErrorBlock message="Não foi possível carregar os modelos." retry={() => void query.refetch()}/>}<div className="sg-template-layout"><section className="sg-panel sg-template-editor"><div className="sg-panel-head"><div><span className="sg-eyebrow">TEXTO-BASE</span><h2>Declaração de Escolaridade</h2></div><span className="sg-version-pill">Versão ativa · v{active?.version ?? 1}</span></div><form id="sg-template-form" className="sg-form" onSubmit={submit}><Field label="Nome do modelo"><FieldInput value={name} onChange={e => setName(e.target.value)} disabled={!canEdit} required/></Field><Field label="Texto da declaração" hint="Os campos entre colchetes são substituídos no momento da emissão."><textarea className="sg-input sg-template-textarea" value={content} onChange={e => setContent(e.target.value)} disabled={!canEdit}/></Field><div className="sg-placeholder-grid"><span>[NOME COMPLETO]</span><span>[DATA DE NASCIMENTO]</span><span>[NOME DA MÃE OU RESPONSÁVEL]</span><span>[MODALIDADE]</span><span>[ANO LETIVO]</span><span>[SÉRIE]</span><span>[TURMA]</span><span>[TURNO]</span><span>[DIA] · [MÊS] · [ANO]</span></div>{canEdit && <div className="sg-warning-inline"><CircleAlert size={16}/> Salvar cria uma nova versão; não modifica documentos históricos.</div>}</form></section><aside className="sg-panel sg-version-panel"><div className="sg-panel-head"><div><span className="sg-eyebrow">CONTROLE DE VERSÕES</span><h2>Histórico do modelo</h2></div></div>{query.isLoading ? <LoadingBlock/> : query.data?.length ? <div className="sg-version-list">{query.data.map(item => <button key={item.id} className={`sg-version-row ${item.id === selectedId ? "sg-version-selected" : ""}`} onClick={() => { setSelectedId(item.id); setName(item.name); setContent(item.content); }}><span className="sg-version-icon"><FileText size={16}/></span><span><strong>{item.name}</strong><small>Versão {item.version} · {formatDate(item.createdAt)}</small></span>{item.active && <span className="sg-active-tag">Ativo</span>}</button>)}</div> : <EmptyState title="Nenhum modelo registrado" detail="O modelo inicial será criado na configuração do sistema."/>}<div className="sg-info-banner"><ShieldCheck size={16}/> O conteúdo utilizado fica copiado em cada declaração emitida.</div></aside></div>
  </div>;
}
