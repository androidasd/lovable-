import type React from "react";
import type { ReactNode } from "react";
import { BookOpenText, CircleAlert, FilePlus2, FileText, KeyRound, LayoutDashboard, Settings, ShieldCheck, Users, X } from "lucide-react";
import type { AppRouter } from "../../../../server/routers";
import type { inferRouterOutputs } from "@trpc/server";
import { BASE_DECLARATION_TEXT } from "@shared/const";

// Infer application data from the API contract so the UI remains aligned with the server.
export type Outputs = inferRouterOutputs<AppRouter>;
export type Student = Outputs["sigde"]["students"]["list"][number];
export type DeclarationRow = Outputs["sigde"]["declarations"]["list"][number];
export type SavedDeclaration = Outputs["sigde"]["declarations"]["get"];
export type SchoolSettings = NonNullable<Outputs["sigde"]["settings"]["get"]>;
export type EmissionSettings = NonNullable<Outputs["sigde"]["settings"]["forEmission"]>;
export type Shift = "MANHÃ" | "TARDE" | "NOITE" | "INTEGRAL";
export type EnrollmentStatus = "ATIVA" | "INATIVA" | "TRANSFERIDA" | "CONCLUÍDA";
export type UserRole = "admin" | "secretaria" | "consulta" | "user";
export type StudentFormData = {
  fullName: string; birthDate: string; motherName: string; fatherName: string; guardianName: string;
  enrollmentNumber: string; schoolYear: string; grade: string; className: string; shift: Shift;
  modality: string; enrollmentStatus: EnrollmentStatus;
};
export type DeclarationFormData = {
  fullName: string; birthDate: string; motherName: string; fatherName: string; guardianName: string;
  schoolYear: string; grade: string; className: string; shift: Shift; modality: string;
  issuedAt: string; signerName: string; signerRole: string; templateId: number | null;
};

export type NavItem = { href: string; label: string; icon: typeof LayoutDashboard };
export const navItems: NavItem[] = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/alunos", label: "Cadastro de alunos", icon: Users },
  { href: "/declaracoes/nova", label: "Emitir declaração", icon: FilePlus2 },
  { href: "/declaracoes", label: "Declarações emitidas", icon: FileText },
  { href: "/modelos", label: "Modelos de documentos", icon: BookOpenText },
  { href: "/configuracoes", label: "Configurações da escola", icon: Settings },
  { href: "/usuarios", label: "Usuários e permissões", icon: ShieldCheck },
  { href: "/minha-senha", label: "Minha senha", icon: KeyRound },
];
export const baseTemplate = BASE_DECLARATION_TEXT;
export const defaultShift: Shift = "NOITE";
export const emptyStudent: StudentFormData = {
  fullName: "", birthDate: "", motherName: "", fatherName: "", guardianName: "", enrollmentNumber: "",
  schoolYear: String(new Date().getFullYear()), grade: "", className: "", shift: defaultShift,
  modality: "Ensino Médio (SOME REGULAR)", enrollmentStatus: "ATIVA",
};
export const localToday = () => {
  const date = new Date();
  date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
  return date.toISOString().slice(0, 10);
};
export const emptyDeclaration = (): DeclarationFormData => ({
  fullName: "", birthDate: "", motherName: "", fatherName: "", guardianName: "",
  schoolYear: String(new Date().getFullYear()), grade: "", className: "", shift: defaultShift,
  modality: "Ensino Médio (SOME REGULAR)", issuedAt: localToday(), signerName: "", signerRole: "", templateId: null,
});
export const humanRole = (role: UserRole | null | undefined) => role === "admin" ? "Administrador" : role === "secretaria" ? "Secretaria" : role === "consulta" ? "Consulta" : "Acesso pendente";
export const humanStatus = (status: string) => ({ ATIVA: "Ativa", INATIVA: "Inativa", TRANSFERIDA: "Transferida", CONCLUÍDA: "Concluída", EMITIDA: "Emitida", CANCELADA: "Cancelada" } as Record<string, string>)[status] ?? status;
export const fileStem = (name: string) => name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/[^A-Z0-9]+/g, "_").replace(/^_|_$/g, "") || "ALUNO";
export const formatDate = (value: string | Date | null | undefined) => {
  if (!value) return "—";
  const date = typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value) ? new Date(`${value}T12:00:00`) : new Date(value);
  return Number.isNaN(date.getTime()) ? String(value) : new Intl.DateTimeFormat("pt-BR", { timeZone: "UTC" }).format(date);
};
export const formatLongDate = (value: Date) => new Intl.DateTimeFormat("pt-BR", { dateStyle: "full" }).format(value);
export const csvCell = (value: unknown) => `"${String(value ?? "").replaceAll('"', '""')}"`;

export function Button({ children, variant = "primary", className = "", ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "secondary" | "ghost" | "danger" }) {
  return <button className={`sg-btn sg-btn-${variant} ${className}`} {...props}>{children}</button>;
}
export function PageTitle({ eyebrow, title, subtitle, action }: { eyebrow?: string; title: string; subtitle?: string; action?: ReactNode }) {
  return <div className="sg-page-title"><div>{eyebrow && <div className="sg-eyebrow">{eyebrow}</div>}<h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>{action}</div>;
}
export function Field({ label, hint, children, className = "" }: { label: string; hint?: string; children: ReactNode; className?: string }) {
  return <label className={`sg-field ${className}`}><span>{label}</span>{children}{hint && <small>{hint}</small>}</label>;
}
export function Modal({ title, children, onClose, wide = false }: { title: string; children: ReactNode; onClose: () => void; wide?: boolean }) {
  return <div className="sg-overlay" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}><section className={`sg-modal ${wide ? "sg-modal-wide" : ""}`} role="dialog" aria-modal="true" aria-label={title}><div className="sg-modal-head"><div><span className="sg-eyebrow">SIGDE · Secretaria escolar</span><h2>{title}</h2></div><button className="sg-icon-btn" onClick={onClose} aria-label="Fechar"><X size={18}/></button></div>{children}</section></div>;
}
export function LoadingBlock({ label = "Carregando dados" }: { label?: string }) {
  return <div className="sg-loading"><span className="sg-spinner"/><span>{label}</span></div>;
}
export function ErrorBlock({ message, retry }: { message: string; retry?: () => void }) {
  return <div className="sg-error"><CircleAlert size={19}/><span>{message}</span>{retry && <button onClick={retry}>Tentar novamente</button>}</div>;
}
export function EmptyState({ icon: Icon = FileText, title, detail, action }: { icon?: typeof FileText; title: string; detail: string; action?: ReactNode }) {
  return <div className="sg-empty"><div className="sg-empty-icon"><Icon size={22}/></div><h3>{title}</h3><p>{detail}</p>{action}</div>;
}
export function StatusPill({ status }: { status: string }) {
  return <span className={`sg-status sg-status-${status.toLowerCase()}`}><i/>{humanStatus(status)}</span>;
}
export function FieldInput(props: React.InputHTMLAttributes<HTMLInputElement>) { return <input className="sg-input" {...props}/>; }
export function FieldSelect(props: React.SelectHTMLAttributes<HTMLSelectElement>) { return <select className="sg-input sg-select" {...props}/>; }
