import { useState, type ChangeEvent, type FormEvent } from "react";
import { ArrowDownToLine, Check, CircleAlert, Download, FilePlus2, FileSpreadsheet, FileText, Filter, RefreshCw, Search, ShieldCheck, Users, X } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Button, EmptyState, ErrorBlock, Field, FieldInput, FieldSelect, LoadingBlock, Modal, PageTitle, StatusPill, defaultShift, emptyStudent, formatDate, humanStatus, type EnrollmentStatus, type Shift, type Student, type StudentFormData, type UserRole } from "./common";

function studentPayload(student?: Student | null): StudentFormData {
  return student ? {
    fullName: student.fullName, birthDate: student.birthDate, motherName: student.motherName,
    fatherName: student.fatherName ?? "", guardianName: student.guardianName ?? "",
    enrollmentNumber: student.enrollmentNumber, schoolYear: student.schoolYear, grade: student.grade,
    className: student.className, shift: student.shift, modality: student.modality,
    enrollmentStatus: student.enrollmentStatus,
  } : { ...emptyStudent };
}

export function StudentsPage() {
  const [search, setSearch] = useState(() => new URLSearchParams(window.location.search).get("search") ?? "");
  const [gradeFilter, setGradeFilter] = useState("");
  const [classFilter, setClassFilter] = useState("");
  const [shiftFilter, setShiftFilter] = useState<Shift | "">("");
  const [statusFilter, setStatusFilter] = useState<EnrollmentStatus | "">("");
  const query = trpc.sigde.students.list.useQuery({ search: search || undefined, grade: gradeFilter || undefined, className: classFilter || undefined, shift: shiftFilter || undefined, status: statusFilter || undefined });
  const utils = trpc.useUtils();
  const [editing, setEditing] = useState<Student | null | false>(false);
  const [importOpen, setImportOpen] = useState(false);
  const [importRows, setImportRows] = useState<StudentFormData[]>([]);
  const [importErrors, setImportErrors] = useState<string[]>([]);
  const [importLoading, setImportLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const me = trpc.auth.me.useQuery(undefined, { retry: false });
  const role = (me.data?.role ?? "user") as UserRole;
  const canEdit = role === "admin" || role === "secretaria";
  const inactivate = trpc.sigde.students.inactivate.useMutation({ onSuccess: () => { toast.success("Matrícula inativada."); void utils.sigde.students.list.invalidate(); void utils.sigde.dashboard.invalidate(); } });
  const save = trpc.sigde.students.save.useMutation({ onSuccess: (result) => { toast.success(editing ? "Cadastro atualizado." : "Aluno cadastrado."); if (result.duplicateWarning) toast.warning("Cadastro salvo. Confira se já existe outro aluno com o mesmo nome e nascimento."); void utils.sigde.students.list.invalidate(); void utils.sigde.dashboard.invalidate(); setEditing(false); setSaving(false); }, onError: e => { toast.error(e.message); setSaving(false); } });
  const grades = [...new Set((query.data ?? []).map(s => s.grade))].sort();
  const classes = [...new Set((query.data ?? []).map(s => s.className))].sort();
  const handleStudentSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!canEdit || editing === false) return;
    const form = event.currentTarget;
    const values = Object.fromEntries(new FormData(form).entries()) as Record<string, string>;
    setSaving(true);
    save.mutate({ ...studentPayload(editing || null), ...values, fatherName: values.fatherName || null, guardianName: values.guardianName || null, shift: values.shift as Shift, enrollmentStatus: values.enrollmentStatus as EnrollmentStatus, id: editing ? editing.id : undefined });
  };
  let xlsxLib: typeof import("xlsx") | undefined;
  const normalize = (value: string) => value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR").trim();
  const parseDate = (value: unknown) => {
    if (value instanceof Date && !Number.isNaN(value.getTime())) return `${value.getFullYear()}-${String(value.getMonth() + 1).padStart(2, "0")}-${String(value.getDate()).padStart(2, "0")}`;
    if (typeof value === "number") { const d = xlsxLib?.SSF.parse_date_code(value); return d ? `${d.y}-${String(d.m).padStart(2, "0")}-${String(d.d).padStart(2, "0")}` : ""; }
    const text = String(value ?? "").trim();
    const br = text.match(/^(\d{1,2})[./-](\d{1,2})[./-](\d{4})$/);
    if (br) return `${br[3]}-${br[2].padStart(2, "0")}-${br[1].padStart(2, "0")}`;
    return /^\d{4}-\d{2}-\d{2}$/.test(text) ? text : "";
  };
  const chooseValue = (row: Record<string, unknown>, keys: string[]) => {
    const entry = Object.entries(row).find(([key]) => keys.includes(normalize(key)));
    return entry?.[1];
  };
  const normalizeShift = (value: unknown): Shift | null => {
    const s = normalize(String(value ?? ""));
    if (s.includes("manha") || s.includes("matutino")) return "MANHÃ";
    if (s.includes("tarde") || s.includes("vespertino")) return "TARDE";
    if (s.includes("noite") || s.includes("noturno")) return "NOITE";
    if (s.includes("integral")) return "INTEGRAL";
    return null;
  };
  const parseImport = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]; if (!file) return;
    setImportErrors([]); setImportRows([]); setImportOpen(true);
    try {
      const XLSX = await import("xlsx");
      xlsxLib = XLSX;
      const workbook = XLSX.read(await file.arrayBuffer(), { type: "array", cellDates: true });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const raw = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: "" });
      const errors: string[] = [];
      const rows = raw.flatMap((row: Record<string, unknown>, index: number) => {
        const fullName = String(chooseValue(row, ["nome completo", "nome do aluno", "aluno", "nome"]) ?? "").trim();
        const birthDate = parseDate(chooseValue(row, ["data de nascimento", "nascimento", "data nascimento"]));
        const motherName = String(chooseValue(row, ["nome da mae", "mae", "nome mae", "filiacao materna"]) ?? "").trim();
        const enrollmentNumber = String(chooseValue(row, ["matricula", "numero de matricula", "n matricula"]) ?? "").trim();
        const schoolYear = String(chooseValue(row, ["ano letivo", "ano"]) ?? new Date().getFullYear()).trim();
        const grade = String(chooseValue(row, ["serie", "serie ano", "ano serie", "ano escolar"]) ?? "").trim();
        const className = String(chooseValue(row, ["turma", "classe"]) ?? "").trim();
        const parsedShift = normalizeShift(chooseValue(row, ["turno", "periodo"]));
        const rawStatus = chooseValue(row, ["situacao da matricula", "situacao", "status"]);
        const statusRaw = normalize(String(rawStatus ?? ""));
        const statusMap: Record<string, EnrollmentStatus> = {
          ativa: "ATIVA", ativo: "ATIVA", inativa: "INATIVA", inativo: "INATIVA",
          transferida: "TRANSFERIDA", transferido: "TRANSFERIDA", concluida: "CONCLUÍDA", concluido: "CONCLUÍDA",
        };
        const status = statusRaw ? statusMap[statusRaw] : "ATIVA";
        if (!fullName || !birthDate || !motherName || !enrollmentNumber || !/^\d{4}$/.test(schoolYear) || !grade || !className || !parsedShift || !status) {
          errors.push(`Linha ${index + 2}: confira nome, nascimento, mãe, matrícula, ano letivo, série, turma, turno e situação. A situação pode ficar em branco para usar ATIVA.`); return [];
        }
        return [{ fullName, birthDate, motherName, fatherName: String(chooseValue(row, ["nome do pai", "pai", "nome pai"]) ?? "").trim(), guardianName: String(chooseValue(row, ["responsavel legal", "responsavel", "tutor"]) ?? "").trim(), enrollmentNumber, schoolYear, grade, className, shift: parsedShift, modality: String(chooseValue(row, ["modalidade de ensino", "modalidade"]) ?? "Ensino Médio").trim() || "Ensino Médio", enrollmentStatus: status }];
      });
      if (rows.length > 500) { setImportErrors(["O arquivo excede o limite de 500 linhas por importação."]); return; }
      setImportRows(rows); setImportErrors(errors);
      if (!rows.length && !errors.length) setImportErrors(["Não há linhas de alunos na primeira planilha."]);
    } catch { setImportErrors(["Não foi possível ler o arquivo. Use uma planilha Excel ou CSV válida."]); }
    event.target.value = "";
  };
  const submitImport = async () => {
    if (!importRows.length) return;
    setImportLoading(true);
    try {
      const result = await utils.client.sigde.students.importMany.mutate({ rows: importRows });
      toast.success(`${result.importedCount} aluno(s) importado(s).`);
      if (result.skipped.length) toast.warning(`${result.skipped.length} linha(s) ignoradas; consulte os detalhes abaixo.`);
      setImportErrors([...importErrors, ...result.skipped.map(row => `Linha ${row.row}: ${row.reason}`)]);
      setImportRows([]); void query.refetch(); void utils.sigde.dashboard.invalidate();
    } catch (error) { toast.error(error instanceof Error ? error.message : "Falha na importação."); }
    finally { setImportLoading(false); }
  };
  const editStudent = editing ? editing : null;
  return <div className="sg-page">
    <PageTitle eyebrow="BASE ESCOLAR" title="Cadastro de alunos" subtitle="Organize matrículas e localize informações escolares com rapidez." action={canEdit ? <div className="sg-title-actions"><label className="sg-btn sg-btn-secondary sg-file-action"><FileSpreadsheet size={17}/> Importar planilha<input type="file" accept=".csv,.xls,.xlsx" onChange={parseImport}/></label><Button onClick={() => setEditing(null)}><Users size={17}/> Novo aluno</Button></div> : undefined}/>
    {!canEdit && <div className="sg-info-banner"><ShieldCheck size={17}/> Seu perfil permite consultar os cadastros, mas não alterá-los.</div>}
    <section className="sg-panel sg-list-panel"><div className="sg-list-toolbar"><div className="sg-search"><Search size={17}/><input aria-label="Pesquisar aluno" placeholder="Buscar por nome ou matrícula" value={search} onChange={e => setSearch(e.target.value)}/>{search && <button onClick={() => setSearch("")} aria-label="Limpar busca"><X size={15}/></button>}</div><div className="sg-filter-group"><Filter size={15}/><select value={gradeFilter} onChange={e => setGradeFilter(e.target.value)}><option value="">Todas as séries</option>{grades.map(g => <option key={g}>{g}</option>)}</select><select value={classFilter} onChange={e => setClassFilter(e.target.value)}><option value="">Todas as turmas</option>{classes.map(c => <option key={c}>{c}</option>)}</select><select value={shiftFilter} onChange={e => setShiftFilter(e.target.value as Shift | "")}><option value="">Todos os turnos</option>{["MANHÃ", "TARDE", "NOITE", "INTEGRAL"].map(s => <option key={s}>{s}</option>)}</select><select value={statusFilter} onChange={e => setStatusFilter(e.target.value as EnrollmentStatus | "")}><option value="">Todas as situações</option>{["ATIVA", "INATIVA", "TRANSFERIDA", "CONCLUÍDA"].map(s => <option key={s}>{humanStatus(s)}</option>)}</select></div></div>
      {query.isLoading ? <LoadingBlock label="Buscando alunos"/> : query.error ? <ErrorBlock message="Não foi possível consultar os alunos." retry={() => void query.refetch()}/> : query.data?.length ? <div className="sg-table-wrap"><table className="sg-table"><thead><tr><th>Aluno</th><th>Matrícula</th><th>Série / turma</th><th>Ano</th><th>Turno</th><th>Situação</th>{canEdit && <th/>}</tr></thead><tbody>{query.data.map(student => <tr key={student.id}><td><strong>{student.fullName}</strong><small>Nasc. {formatDate(student.birthDate)}</small></td><td className="sg-code">{student.enrollmentNumber}</td><td>{student.grade}<small>{student.className}</small></td><td>{student.schoolYear}</td><td>{student.shift}</td><td><StatusPill status={student.enrollmentStatus}/></td>{canEdit && <td><div className="sg-row-actions"><button title="Editar aluno" onClick={() => setEditing(student)}>Editar</button>{student.enrollmentStatus === "ATIVA" && <button className="sg-row-danger" title="Inativar matrícula" onClick={() => { if (window.confirm(`Inativar a matrícula de ${student.fullName}?`)) inactivate.mutate({ id: student.id }); }}>Inativar</button>}</div></td>}</tr>)}</tbody></table></div> : <EmptyState icon={Users} title={search ? "Nenhum resultado encontrado" : "Nenhum aluno cadastrado"} detail={search ? "Revise o nome ou a matrícula e tente novamente." : "Cadastre o primeiro aluno ou importe uma planilha validada."} action={canEdit && !search ? <Button onClick={() => setEditing(null)}><Users size={16}/> Cadastrar aluno</Button> : undefined}/>}</section>
    {editing !== false && canEdit && <Modal title={editStudent ? "Editar aluno" : "Novo cadastro de aluno"} onClose={() => setEditing(false)} wide><form className="sg-form" onSubmit={handleStudentSubmit}><div className="sg-form-section-title">Dados pessoais</div><div className="sg-form-grid"><Field label="Nome completo"><FieldInput name="fullName" defaultValue={editStudent?.fullName ?? ""} required maxLength={240}/></Field><Field label="Data de nascimento"><FieldInput name="birthDate" type="date" defaultValue={editStudent?.birthDate ?? ""} required/></Field><Field label="Nome da mãe"><FieldInput name="motherName" defaultValue={editStudent?.motherName ?? ""} required maxLength={240}/></Field><Field label="Nome do pai (opcional)"><FieldInput name="fatherName" defaultValue={editStudent?.fatherName ?? ""} maxLength={240}/></Field><Field label="Responsável legal (opcional)"><FieldInput name="guardianName" defaultValue={editStudent?.guardianName ?? ""} maxLength={240}/></Field></div><div className="sg-form-section-title">Dados da matrícula</div><div className="sg-form-grid"><Field label="Número de matrícula"><FieldInput name="enrollmentNumber" defaultValue={editStudent?.enrollmentNumber ?? ""} required maxLength={80}/></Field><Field label="Ano letivo"><FieldInput name="schoolYear" defaultValue={editStudent?.schoolYear ?? String(new Date().getFullYear())} required pattern="\d{4}" maxLength={4}/></Field><Field label="Série / ano"><FieldInput name="grade" defaultValue={editStudent?.grade ?? ""} required placeholder="Ex.: 3ª série"/></Field><Field label="Turma"><FieldInput name="className" defaultValue={editStudent?.className ?? ""} required placeholder="Ex.: M3NNG03"/></Field><Field label="Turno"><FieldSelect name="shift" defaultValue={editStudent?.shift ?? defaultShift}>{["MANHÃ", "TARDE", "NOITE", "INTEGRAL"].map(v => <option key={v}>{v}</option>)}</FieldSelect></Field><Field label="Modalidade de ensino"><FieldInput name="modality" defaultValue={editStudent?.modality ?? "Ensino Médio (SOME REGULAR)"} required/></Field><Field label="Situação da matrícula"><FieldSelect name="enrollmentStatus" defaultValue={editStudent?.enrollmentStatus ?? "ATIVA"}>{["ATIVA", "INATIVA", "TRANSFERIDA", "CONCLUÍDA"].map(v => <option key={v} value={v}>{humanStatus(v)}</option>)}</FieldSelect></Field></div><div className="sg-modal-actions"><Button type="button" variant="secondary" onClick={() => setEditing(false)}>Cancelar</Button><Button type="submit" disabled={saving}>{saving ? <><span className="sg-spinner"/> Salvando...</> : <><Check size={16}/> Salvar cadastro</>}</Button></div></form></Modal>}
    {importOpen && <Modal title="Importar alunos por planilha" onClose={() => { setImportOpen(false); setImportRows([]); setImportErrors([]); }} wide><div className="sg-import-body"><div className="sg-info-banner"><FileSpreadsheet size={17}/> A planilha é lida nesta sessão. Confira a pré-visualização antes de confirmar a gravação.</div><p className="sg-muted-copy">Colunas aceitas: nome completo, data de nascimento, nome da mãe, matrícula, ano letivo, série, turma, turno; pai, responsável, modalidade e situação são opcionais.</p>{importErrors.length > 0 && <div className="sg-import-errors"><strong><CircleAlert size={16}/> Linhas que precisam de atenção</strong><ul>{importErrors.map((e, i) => <li key={i}>{e}</li>)}</ul></div>}{importRows.length ? <><div className="sg-import-summary"><strong>{importRows.length}</strong> linha(s) válida(s) para importação</div><div className="sg-table-wrap sg-import-table"><table className="sg-table"><thead><tr><th>Aluno</th><th>Matrícula</th><th>Ano / série</th><th>Turma</th><th>Turno</th></tr></thead><tbody>{importRows.slice(0, 8).map((row, i) => <tr key={`${row.enrollmentNumber}-${i}`}><td>{row.fullName}</td><td>{row.enrollmentNumber}</td><td>{row.schoolYear} · {row.grade}</td><td>{row.className}</td><td>{row.shift}</td></tr>)}</tbody></table></div>{importRows.length > 8 && <small className="sg-muted-copy">Exibindo 8 de {importRows.length} registros válidos.</small>}</> : !importErrors.length ? <EmptyState icon={FileSpreadsheet} title="Selecione uma planilha" detail="São aceitos arquivos .xlsx, .xls e .csv, até 500 alunos por lote."/> : null}</div><div className="sg-modal-actions"><Button variant="secondary" onClick={() => setImportOpen(false)}>Cancelar</Button><Button onClick={() => void submitImport()} disabled={!importRows.length || importLoading}>{importLoading ? <><span className="sg-spinner"/> Importando...</> : <><Check size={16}/> Confirmar importação</>}</Button></div></Modal>}
  </div>;
}
