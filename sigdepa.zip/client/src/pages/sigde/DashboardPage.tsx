import { useState, type FormEvent } from "react";
import { Activity, ArrowRight, CalendarDays, Clock3, FilePlus2, FileText, GraduationCap, Search, ShieldCheck, SlidersHorizontal, Users } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { Button, EmptyState, ErrorBlock, LoadingBlock, PageTitle, StatusPill, formatDate, formatLongDate } from "./common";

export function DashboardPage({ setPath }: { setPath: (path: string) => void }) {
  const query = trpc.sigde.dashboard.useQuery(undefined, { retry: false });
  const [quickSearch, setQuickSearch] = useState("");
  const submitSearch = (event: FormEvent) => {
    event.preventDefault();
    const value = quickSearch.trim();
    if (value) setPath(`/alunos?search=${encodeURIComponent(value)}`);
  };
  const data = query.data;
  const maxGrade = Math.max(1, ...(data?.grades.map(g => Number(g.total)) ?? [1]));
  return <div className="sg-page">
    <PageTitle eyebrow="PAINEL DE CONTROLE" title="Dashboard" subtitle={`Visão geral da secretaria · ${formatLongDate(new Date())}`} action={<Button onClick={() => setPath("/declaracoes/nova")}><FilePlus2 size={17}/> Nova declaração</Button>}/>
    {query.error && <ErrorBlock message="Não foi possível carregar os indicadores. Verifique o banco de dados ou sua permissão." retry={() => void query.refetch()}/>}
    {query.isLoading ? <LoadingBlock label="Atualizando indicadores"/> : <>
      <div className="sg-stat-grid">
        <div className="sg-stat-card"><div className="sg-stat-top"><span>Alunos cadastrados</span><div className="sg-stat-icon sg-stat-blue"><Users size={18}/></div></div><strong>{data?.totalStudents ?? 0}</strong><small>Registros escolares ativos e históricos</small></div>
        <div className="sg-stat-card"><div className="sg-stat-top"><span>Declarações emitidas</span><div className="sg-stat-icon sg-stat-navy"><FileText size={18}/></div></div><strong>{data?.totalDeclarations ?? 0}</strong><small>Documentos registrados no SIGDE</small></div>
        <div className="sg-stat-card"><div className="sg-stat-top"><span>Emitidas neste mês</span><div className="sg-stat-icon sg-stat-amber"><CalendarDays size={18}/></div></div><strong>{data?.issuedThisMonth ?? 0}</strong><small>Declarações do mês corrente</small></div>
        <div className="sg-stat-card sg-stat-highlight"><div className="sg-stat-top"><span>Acesso seguro</span><div className="sg-stat-icon sg-stat-green"><ShieldCheck size={18}/></div></div><strong>Ativo</strong><small>Autenticação institucional habilitada</small></div>
      </div>
      <div className="sg-dashboard-grid">
        <section className="sg-panel sg-chart-panel"><div className="sg-panel-head"><div><span className="sg-eyebrow">DISTRIBUIÇÃO</span><h2>Alunos por série</h2></div><span className="sg-panel-tag"><GraduationCap size={15}/> Matrículas ativas</span></div>
          {data?.grades.length ? <div className="sg-bars">{data.grades.map((item, i) => <div className="sg-bar-row" key={item.grade}><span>{item.grade}</span><div className="sg-bar-track"><i style={{ width: `${Math.max(5, Number(item.total) / maxGrade * 100)}%`, animationDelay: `${i * 65}ms` }}/></div><strong>{item.total}</strong></div>)}</div> : <EmptyState icon={GraduationCap} title="Sem dados de matrículas" detail="A distribuição por série aparecerá quando os alunos forem cadastrados." action={<Button variant="secondary" onClick={() => setPath("/alunos")}><Users size={16}/> Ir para cadastro</Button>}/>} 
        </section>
        <section className="sg-panel sg-quick-panel"><div className="sg-panel-head"><div><span className="sg-eyebrow">ATALHOS</span><h2>Rotina da secretaria</h2></div><SlidersHorizontal size={18} className="sg-muted-icon"/></div>
          <form className="sg-dashboard-search" onSubmit={submitSearch}><div className="sg-search"><Search size={17}/><input aria-label="Pesquisa rápida por nome ou matrícula" placeholder="Pesquisar aluno por nome ou matrícula" value={quickSearch} onChange={e => setQuickSearch(e.target.value)}/></div><Button type="submit" disabled={!quickSearch.trim()}><Search size={15}/> Buscar</Button></form>
          <div className="sg-quick-list"><button onClick={() => setPath("/declaracoes/nova")}><span className="sg-quick-icon"><FilePlus2 size={19}/></span><span><strong>Emitir declaração</strong><small>Preencher e gerar documento PDF</small></span><ArrowRight size={16}/></button><button onClick={() => setPath("/alunos")}><span className="sg-quick-icon"><Users size={19}/></span><span><strong>Localizar aluno</strong><small>Pesquisar por nome ou matrícula</small></span><ArrowRight size={16}/></button><button onClick={() => setPath("/declaracoes")}><span className="sg-quick-icon"><Activity size={19}/></span><span><strong>Consultar histórico</strong><small>Ver documentos emitidos e status</small></span><ArrowRight size={16}/></button></div><div className="sg-quick-note"><Clock3 size={15}/> Os documentos salvos mantêm uma cópia dos dados usados na emissão.</div></section>
      </div>
      <section className="sg-panel sg-recent-panel"><div className="sg-panel-head"><div><span className="sg-eyebrow">MOVIMENTAÇÃO</span><h2>Últimas declarações</h2></div><button className="sg-text-link" onClick={() => setPath("/declaracoes")}>Ver histórico completo <ArrowRight size={15}/></button></div>
        {data?.recent.length ? <div className="sg-table-wrap"><table className="sg-table"><thead><tr><th>Nº do documento</th><th>Aluno</th><th>Série</th><th>Emissão</th><th>Status</th></tr></thead><tbody>{data.recent.map(row => <tr key={row.id} onClick={() => setPath("/declaracoes")}><td className="sg-code">{row.documentNumber}</td><td><strong>{row.fullName || "Cadastro manual"}</strong><small>Emitida por {row.issuerName || "Usuário SIGDE"}</small></td><td>{row.grade || "—"}</td><td>{formatDate(row.issuedAt)}</td><td><StatusPill status={row.status}/></td></tr>)}</tbody></table></div> : <EmptyState title="Nenhuma declaração emitida" detail="Quando um documento for emitido, ele aparecerá neste histórico." action={<Button variant="secondary" onClick={() => setPath("/declaracoes/nova")}><FilePlus2 size={16}/> Emitir primeira declaração</Button>}/>}</section>
      <div className="sg-dashboard-footnote"><ShieldCheck size={15}/> Os dados do painel são carregados do cadastro institucional; nenhum registro de demonstração é utilizado.</div>
    </>}
  </div>;
}
