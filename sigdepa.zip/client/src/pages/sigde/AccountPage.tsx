import { useState, type FormEvent } from "react";
import { KeyRound, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Button, Field, FieldInput, PageTitle } from "./common";

export function AccountPage() {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const change = trpc.auth.changePassword.useMutation({
    onSuccess: () => {
      toast.success("Senha alterada.");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    },
    onError: error => toast.error(error.message),
  });
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (newPassword !== confirmPassword) { toast.error("As senhas novas não coincidem."); return; }
    change.mutate({ currentPassword, newPassword });
  };

  return <div className="sg-page">
    <PageTitle eyebrow="SEGURANÇA DA CONTA" title="Minha senha" subtitle="Atualize suas credenciais de acesso ao SIGDE."/>
    <section className="sg-panel sg-password-panel"><div className="sg-panel-head"><div><span className="sg-eyebrow">CREDENCIAIS LOCAIS</span><h2><KeyRound size={18}/> Alterar senha</h2></div><ShieldCheck size={20}/></div>
      <form className="sg-password-form" onSubmit={submit}>
        <Field label="Senha atual"><FieldInput type="password" autoComplete="current-password" minLength={1} maxLength={128} required value={currentPassword} onChange={event => setCurrentPassword(event.target.value)}/></Field>
        <Field label="Nova senha" hint="Use pelo menos 12 caracteres."><FieldInput type="password" autoComplete="new-password" minLength={12} maxLength={128} required value={newPassword} onChange={event => setNewPassword(event.target.value)}/></Field>
        <Field label="Confirme a nova senha"><FieldInput type="password" autoComplete="new-password" minLength={12} maxLength={128} required value={confirmPassword} onChange={event => setConfirmPassword(event.target.value)}/></Field>
        <div className="sg-password-actions"><Button type="submit" disabled={change.isPending}>{change.isPending ? "Salvando..." : "Alterar senha"}</Button></div>
      </form>
      <p className="sg-auth-note">Se você não possui uma senha local, solicite que o Administrador defina ou redefina sua senha. O sistema não envia links de recuperação por e-mail.</p>
    </section>
  </div>;
}
