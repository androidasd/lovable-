import type { ReactNode } from "react";
import { useLocation } from "wouter";
import { ShieldCheck } from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { AppShell, LoginScreen } from "./sigde/Shell";
import { DashboardPage } from "./sigde/DashboardPage";
import { StudentsPage } from "./sigde/StudentsPage";
import { DeclarationPage } from "./sigde/DeclarationPage";
import { DeclarationsPage } from "./sigde/DeclarationsPage";
import { SettingsPage } from "./sigde/SettingsPage";
import { TemplatesPage } from "./sigde/TemplatesPage";
import { UsersPage } from "./sigde/UsersPage";
import { AccountPage } from "./sigde/AccountPage";
import { EmptyState, type UserRole } from "./sigde/common";

export default function Home() {
  const auth = useAuth();
  const [path, setPath] = useLocation();
  const role = (auth.user?.role ?? "user") as UserRole;
  if (auth.loading) return <div className="sg-auth-loading"><span className="sg-spinner"/><span>Verificando acesso institucional...</span></div>;
  if (!auth.isAuthenticated) return <LoginScreen/>;
  if (role === "user") {
    const pendingPage = path === "/minha-senha" ? <AccountPage/> : <section className="sg-access-pending"><ShieldCheck size={30}/><h1>Acesso aguardando autorização</h1><p>Sua conta foi autenticada, mas um Administrador precisa atribuir o perfil Consulta, Secretaria ou Administrador antes de você acessar dados escolares.</p><div className="sg-access-pending-actions"><button className="sg-btn sg-btn-secondary" onClick={() => setPath("/minha-senha")}>Alterar minha senha</button><button className="sg-btn sg-btn-ghost" onClick={() => void auth.logout()}>Sair</button></div></section>;
    return <AppShell user={auth.user} onLogout={() => void auth.logout()} role={role} path={path} setPath={setPath}>{pendingPage}</AppShell>;
  }
  let page: ReactNode;
  if (path === "/" || path === "/login") page = <DashboardPage setPath={setPath}/>;
  else if (path === "/alunos") page = <StudentsPage/>;
  else if (path === "/declaracoes/nova") page = role === "admin" || role === "secretaria" ? <DeclarationPage/> : <EmptyState icon={ShieldCheck} title="Acesso somente para secretaria" detail="Seu perfil permite consultar os documentos autorizados, mas não emitir declarações."/>;
  else if (path === "/declaracoes") page = <DeclarationsPage/>;
  else if (path === "/modelos") page = role === "admin" ? <TemplatesPage/> : <EmptyState icon={ShieldCheck} title="Área administrativa" detail="Somente o perfil Administrador pode acessar modelos institucionais."/>;
  else if (path === "/configuracoes") page = role === "admin" ? <SettingsPage/> : <EmptyState icon={ShieldCheck} title="Área administrativa" detail="Somente o perfil Administrador pode acessar as configurações da escola."/>;
  else if (path === "/usuarios") page = <UsersPage/>;
  else if (path === "/minha-senha") page = <AccountPage/>;
  else page = <DashboardPage setPath={setPath}/>;
  return <AppShell user={auth.user} onLogout={() => void auth.logout()} role={role} path={path} setPath={setPath}>{page}</AppShell>;
}
