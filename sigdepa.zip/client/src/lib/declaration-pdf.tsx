import { useEffect, useRef, useState } from "react";
import { Document, Font, Image, Page, StyleSheet, Text, View, pdf } from "@react-pdf/renderer";
import { getDocument, GlobalWorkerOptions, type PDFDocumentProxy, type RenderTask } from "pdfjs-dist";
import pdfWorkerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";
import { BASE_DECLARATION_TEXT } from "@shared/const";

GlobalWorkerOptions.workerSrc = pdfWorkerUrl;
Font.register({ family: "SIGDE-Times", src: "/assets/fonts/LiberationSerif-Regular.ttf", fontWeight: 400 });
Font.register({ family: "SIGDE-Times", src: "/assets/fonts/LiberationSerif-Bold.ttf", fontWeight: 700 });
Font.register({ family: "SIGDE-Arial", src: "/assets/fonts/LiberationSans-Bold.ttf", fontWeight: 700 });

export type DeclarationSnapshot = {
  fullName: string;
  birthDate: string;
  motherName: string;
  fatherName?: string;
  guardianName?: string;
  schoolYear: string;
  grade: string;
  className: string;
  shift: string;
  modality?: string;
  issuedAt: string;
  signerName: string;
  signerRole: string;
  documentNumber?: string;
  status?: "EMITIDA" | "CANCELADA";
  templateContent?: string;
  institution?: {
    name?: string;
    government?: string;
    secretary?: string;
    regionalOffice?: string;
    address?: string;
    municipality?: string;
    state?: string;
    phone?: string;
    inepCode?: string;
    authorizationAct?: string;
    logoData?: string | null;
    signatureData?: string | null;
  } | null;
};

const styles = StyleSheet.create({
  page: {
    paddingTop: 12,
    paddingHorizontal: 52,
    paddingBottom: 24,
    fontFamily: "SIGDE-Times",
    fontSize: 11,
    color: "#161b22",
    lineHeight: 1.45,
  },
  header: { position: "relative", flexDirection: "row", alignItems: "center", height: 80, marginBottom: 15 },
  logo: { width: 64, height: 78, objectFit: "contain", marginRight: 10 },
  heading: { position: "absolute", left: 14.5, right: -14.5, top: 24 },
  headingLine: { width: "100%", textAlign: "center", fontFamily: "SIGDE-Arial", fontWeight: 700, fontSize: 12, lineHeight: 1.15, letterSpacing: 0.07 },
  schoolName: { width: "100%", textAlign: "center", fontFamily: "SIGDE-Arial", fontWeight: 700, fontSize: 12, lineHeight: 1.15, letterSpacing: 0.07, marginTop: 0 },
  details: { marginHorizontal: 33, fontSize: 10.4, lineHeight: 1.42, marginBottom: 44 },
  detailLabel: { fontFamily: "SIGDE-Times", fontWeight: 700 },
  title: { textAlign: "center", fontFamily: "SIGDE-Times", fontWeight: 700, fontSize: 16, textDecoration: "underline", marginLeft: 28, marginBottom: 42 },
  body: { fontSize: 12, lineHeight: 2, textAlign: "justify", marginHorizontal: 30, textIndent: 31 },
  closing: { fontSize: 12, lineHeight: 2, textAlign: "justify", marginHorizontal: 30, textIndent: 31, marginTop: 9 },
  fieldStrong: { fontFamily: "SIGDE-Times", fontWeight: 700 },
  fieldUnderline: { fontFamily: "SIGDE-Times", fontWeight: 700, textDecoration: "underline" },
  placeDate: { textAlign: "center", fontSize: 11.5, marginTop: 49 },
  signatureArea: { alignItems: "center", marginTop: 44 },
  signature: { width: 147, height: 70, objectFit: "contain", marginBottom: 2 },
  signerName: { textAlign: "center", fontFamily: "SIGDE-Times", fontWeight: 700, fontSize: 9.3 },
  signerRole: { textAlign: "center", fontSize: 8.2 },
  cancellationNotice: { textAlign: "center", color: "#a11d24", borderWidth: 1, borderColor: "#a11d24", paddingVertical: 5, marginTop: -22, marginBottom: 18, fontFamily: "SIGDE-Times", fontWeight: 700, fontSize: 10, letterSpacing: 1 },
});

function dateParts(value: string) {
  const parsed = new Date(`${value}T12:00:00`);
  if (Number.isNaN(parsed.getTime())) return { day: "[DIA]", month: "[MÊS]", year: "[ANO]", display: value };
  const month = new Intl.DateTimeFormat("pt-BR", { month: "long" }).format(parsed).toLocaleUpperCase("pt-BR");
  return {
    day: String(parsed.getDate()),
    month,
    year: String(parsed.getFullYear()),
    display: new Intl.DateTimeFormat("pt-BR", { timeZone: "UTC" }).format(parsed),
  };
}

export function fillDeclarationText(snapshot: DeclarationSnapshot) {
  const issueDate = dateParts(snapshot.issuedAt);
  const birthDate = dateParts(snapshot.birthDate).display;
  const motherOrGuardian = snapshot.motherName || snapshot.guardianName || "";
  const filiation = `${motherOrGuardian}${snapshot.fatherName ? ` e ${snapshot.fatherName}` : ""}`;
  const template = snapshot.templateContent || BASE_DECLARATION_TEXT;
  return template
    .replaceAll("[NOME COMPLETO]", (snapshot.fullName || "").toLocaleUpperCase("pt-BR"))
    .replaceAll("[DATA DE NASCIMENTO]", birthDate)
    .replaceAll("[NOME DA MÃE OU RESPONSÁVEL]", filiation.toLocaleUpperCase("pt-BR"))
    .replaceAll("[MODALIDADE]", snapshot.modality || "SOME REGULAR")
    .replaceAll("[ANO LETIVO]", snapshot.schoolYear || "")
    .replaceAll("[SÉRIE]", (snapshot.grade || "").toLocaleUpperCase("pt-BR"))
    .replaceAll("[TURMA]", (snapshot.className || "").toLocaleUpperCase("pt-BR"))
    .replaceAll("[TURNO]", (snapshot.shift || "").toLocaleUpperCase("pt-BR"))
    .replaceAll("[DIA]", issueDate.day)
    .replaceAll("[MÊS]", issueDate.month)
    .replaceAll("[ANO]", issueDate.year);
}

function StandardDeclarationBody({ snapshot }: { snapshot: DeclarationSnapshot }) {
  const name = (snapshot.fullName || "").toLocaleUpperCase("pt-BR");
  const birthDate = dateParts(snapshot.birthDate).display;
  const mother = (snapshot.motherName || snapshot.guardianName || "").toLocaleUpperCase("pt-BR");
  const father = (snapshot.fatherName || "").trim().toLocaleUpperCase("pt-BR");
  const grade = (snapshot.grade || "").toLocaleUpperCase("pt-BR");
  const className = (snapshot.className || "").toLocaleUpperCase("pt-BR");
  const shift = (snapshot.shift || "").toLocaleUpperCase("pt-BR");
  return <>
    <Text style={styles.body} hyphenationCallback={word => [word]}>Declaramos para todos os fins de direito e a quem possa interessar que o (a) aluno (a) <Text style={styles.fieldStrong}>{name}</Text>, nascido (a) em: <Text style={styles.fieldUnderline}>{birthDate}</Text>, filho (a) de: <Text style={styles.fieldUnderline}>{mother}</Text>{father ? <> e <Text style={styles.fieldStrong}>{father}</Text></> : null}, matriculou-se neste Estabelecimento de Ensino, no ano letivo de {snapshot.schoolYear}, para cursar a <Text style={styles.fieldStrong}>{grade}</Text> do Ensino Médio (<Text style={styles.fieldStrong}>SOME REGULAR</Text>), na turma {className}, no turno da <Text style={styles.fieldStrong}>{shift}</Text>, frequentando regularmente as aulas.</Text>
    <Text style={styles.closing} hyphenationCallback={word => [word]}>Por ser verdade, firmo a presente declaração para que surta efeitos legais.</Text>
  </>;
}

export function SchoolDeclarationDocument({ snapshot }: { snapshot: DeclarationSnapshot }) {
  const institution = snapshot.institution ?? {};
  const date = dateParts(snapshot.issuedAt);
  const address = (institution.address || "Rua Sete de Setembro, nº 576 – bairro: Centro").trim().replace(/\.$/, "");
  const authorizationAct = (institution.authorizationAct || "Res. nº 267 de 26/05/2024–CEE/PA").trim().replace(/\.$/, "");
  const isReferenceTemplate = !snapshot.templateContent || snapshot.templateContent === BASE_DECLARATION_TEXT;
  const paragraphs = fillDeclarationText(snapshot).split(/\n\s*\n/).filter(Boolean);
  const logo = institution.logoData || "/assets/logo-governo-para.jpg";
  const customSignature = Boolean(institution.signatureData);
  const signature = institution.signatureData || "/assets/signature-model.jpg";
  return (
    <Document title={`Declaração de Escolaridade${snapshot.status === "CANCELADA" ? " — CANCELADA" : ""} — ${snapshot.fullName || "Aluno"}`} author={institution.name || "SIGDE"}>
      <Page size="A4" style={styles.page}>
        <View style={styles.header}>
          <Image src={logo} style={styles.logo} />
          <View style={styles.heading}>
            <Text style={styles.headingLine}>{institution.government || "GOVERNO DO ESTADO DO PARÁ"}</Text>
            <Text style={styles.headingLine}>{institution.secretary || "SECRETARIA EXECUTIVA DE EDUCAÇÃO"}</Text>
            <Text style={styles.headingLine}>{institution.regionalOffice || "10ª UNIDADE REGIONAL DE EDUCAÇÃO"}</Text>
            <Text style={styles.schoolName}>{institution.name || "COLÉGIO ESTADUAL DE ENSINO MÉDIO ROSA ALVAREZ REBELO"}</Text>
          </View>
        </View>

        <View style={styles.details}>
          <Text><Text style={styles.detailLabel}>Endereço: </Text>{address}.</Text>
          <Text><Text style={styles.detailLabel}>Município: </Text>{institution.municipality || "Senador José Porfírio"} <Text style={styles.detailLabel}>Estado: </Text>{institution.state || "Pará"}</Text>
          <Text><Text style={styles.detailLabel}>Telefone: </Text>{institution.phone || "(091) 3556–1397"}</Text>
          <Text><Text style={styles.detailLabel}>Processo de Autorização da Escola: </Text>{authorizationAct}.</Text>
          <Text><Text style={styles.detailLabel}>Código do INEP: </Text>{institution.inepCode || "15178137"}</Text>
        </View>

        <Text style={styles.title}>DECLARAÇÃO DE ESCOLARIDADE</Text>
        {snapshot.status === "CANCELADA" ? <Text style={styles.cancellationNotice}>CANCELADA — SEM VALIDADE</Text> : null}
        {isReferenceTemplate ? <StandardDeclarationBody snapshot={snapshot}/> : paragraphs.map((paragraph, index) => <Text key={index} style={index === 0 ? styles.body : styles.closing} hyphenationCallback={word => [word]}>{paragraph}</Text>)}
        <Text style={styles.placeDate}>{institution.municipality || "Senador José Porfírio"}/{institution.state === "Pará" || !institution.state ? "PA" : institution.state}, {date.day} de {date.month} de {date.year}.</Text>
        <View style={styles.signatureArea}>
          <Image src={signature} style={styles.signature} />
          {customSignature ? <>
            {snapshot.signerName ? <Text style={styles.signerName}>{snapshot.signerName}</Text> : null}
            {snapshot.signerRole ? <Text style={styles.signerRole}>{snapshot.signerRole}</Text> : null}
          </> : null}
        </View>
      </Page>
    </Document>
  );
}

export function DeclarationPreview({ snapshot, zoom = 1 }: { snapshot: DeclarationSnapshot; zoom?: number }) {
  const [pdfDocument, setPdfDocument] = useState<PDFDocumentProxy | null>(null);
  const [loading, setLoading] = useState(true);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const canvasRefs = useRef<Array<HTMLCanvasElement | null>>([]);

  useEffect(() => {
    let cancelled = false;
    let loadingTask: ReturnType<typeof getDocument> | undefined;
    setPdfDocument(null);
    setLoading(true);
    setPreviewError(null);

    void (async () => {
      try {
        const blob = await makeDeclarationPdf(snapshot);
        if (cancelled) return;
        loadingTask = getDocument({ data: new Uint8Array(await blob.arrayBuffer()), isEvalSupported: false });
        const documentProxy = await loadingTask.promise;
        if (cancelled) {
          void loadingTask.destroy();
          return;
        }
        setPdfDocument(documentProxy);
      } catch {
        if (!cancelled) {
          setPreviewError("A pré-visualização da declaração não pôde ser carregada. Recarregue a página e tente novamente.");
          setLoading(false);
        }
      }
    })();

    return () => {
      cancelled = true;
      if (loadingTask) void loadingTask.destroy();
    };
  }, [snapshot]);

  useEffect(() => {
    if (!pdfDocument) return;
    let cancelled = false;
    const renderTasks: RenderTask[] = [];
    setLoading(true);

    void (async () => {
      try {
        for (let pageNumber = 1; pageNumber <= pdfDocument.numPages; pageNumber += 1) {
          const page = await pdfDocument.getPage(pageNumber);
          if (cancelled) return;
          const canvas = canvasRefs.current[pageNumber - 1];
          const context = canvas?.getContext("2d");
          if (!canvas || !context) throw new Error("Canvas indisponível");

          const renderScale = 1.6;
          const viewport = page.getViewport({ scale: renderScale });
          canvas.width = Math.ceil(viewport.width);
          canvas.height = Math.ceil(viewport.height);
          canvas.style.width = `${viewport.width / renderScale}px`;
          canvas.style.height = `${viewport.height / renderScale}px`;
          const renderTask = page.render({ canvasContext: context, viewport });
          renderTasks.push(renderTask);
          await renderTask.promise;
        }
        if (!cancelled) setLoading(false);
      } catch {
        if (!cancelled) {
          setPreviewError("Não foi possível renderizar a declaração neste navegador. Atualize a página ou tente novamente.");
          setLoading(false);
        }
      }
    })();

    return () => {
      cancelled = true;
      renderTasks.forEach(task => task.cancel());
    };
  }, [pdfDocument]);

  return (
    <div className="pdf-preview-viewport" aria-busy={loading}>
      <div className="pdf-preview-scale" style={{ transform: `scale(${zoom})` }}>
        {pdfDocument && Array.from({ length: pdfDocument.numPages }, (_, index) => (
          <canvas
            key={index + 1}
            ref={element => { canvasRefs.current[index] = element; }}
            className="pdf-preview-page"
            aria-label={`Página ${index + 1} da pré-visualização da declaração`}
          />
        ))}
        {loading && <div className="pdf-preview-message" role="status">Preparando pré-visualização…</div>}
        {previewError && <div className="pdf-preview-message pdf-preview-error" role="alert">{previewError}</div>}
      </div>
    </div>
  );
}

export async function makeDeclarationPdf(snapshot: DeclarationSnapshot): Promise<Blob> {
  return pdf(<SchoolDeclarationDocument snapshot={snapshot} /> as Parameters<typeof pdf>[0]).toBlob();
}

export async function downloadDeclaration(snapshot: DeclarationSnapshot, filename: string) {
  const blob = await makeDeclarationPdf(snapshot);
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

export async function printDeclaration(snapshot: DeclarationSnapshot) {
  const popup = window.open("about:blank", "_blank");
  const blob = await makeDeclarationPdf(snapshot);
  const url = URL.createObjectURL(blob);
  if (popup) {
    popup.location.href = url;
    window.setTimeout(() => popup.print(), 1_500);
  }
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
}
