import { z } from "zod";

export function isValidSchoolDate(value: string) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return false;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (year < 1900 || year > 2100 || month < 1 || month > 12 || day < 1 || day > 31) return false;
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}

export const schoolDateSchema = z.string().refine(isValidSchoolDate, "Informe uma data válida entre 1900 e 2100.");
export const schoolYearSchema = z.string().trim().refine(value => /^\d{4}$/.test(value) && Number(value) >= 1900 && Number(value) <= 2100, "Informe um ano letivo válido entre 1900 e 2100.");
