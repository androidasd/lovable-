import type { CookieOptions, Request } from "express";

export function getSessionCookieOptions(req: Request): CookieOptions {
  const protoValue = req.headers["x-forwarded-proto"];
  const forwardedProto = (Array.isArray(protoValue) ? protoValue[0] : protoValue)?.split(",")[0]?.trim().toLowerCase();
  const hostValue = req.headers["x-forwarded-host"];
  const forwardedHost = (Array.isArray(hostValue) ? hostValue[0] : hostValue)?.split(",")[0]?.trim();
  const host = (forwardedHost || req.headers.host || "").split(",")[0].trim().toLowerCase();
  const loopback = /^(localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/.test(host);
  const localHttp = loopback && !forwardedHost && forwardedProto !== "https";
  // HTTPS Preview is cross-site; localhost HTTP is handled separately for local development.
  return { httpOnly: true, path: "/", sameSite: localHttp ? "lax" : "none", secure: !localHttp };
}
