import { describe, expect, it } from "vitest";
import { csrfOriginAllowed } from "./csrf";

const csrfToken = "A".repeat(43);
const tokenHeaders = {
  cookie: `sigde_csrf=${csrfToken}`,
  "x-sigde-csrf": csrfToken,
};

describe("tRPC mutation CSRF guard", () => {
  it("does not block safe reads", () => {
    expect(csrfOriginAllowed("GET", { host: "sigde.test" })).toBe(true);
  });

  it("accepts a public HTTPS Preview origin with a matching double-submit token", () => {
    expect(csrfOriginAllowed("POST", {
      ...tokenHeaders,
      origin: "https://preview.example.manus.computer",
      host: "internal:3000",
      "x-forwarded-host": "preview.example.manus.computer",
      "x-forwarded-proto": "https",
    })).toBe(true);
  });

  it("accepts the Preview proxy's rewritten loopback Origin only with a token", () => {
    expect(csrfOriginAllowed("POST", {
      ...tokenHeaders,
      origin: "http://127.0.0.1:3000",
      host: "127.0.0.1:3000",
      "x-forwarded-host": "preview.example.manus.computer",
      "x-forwarded-proto": "https",
    })).toBe(true);
  });

  it("rejects cross-site, missing-origin, and missing-token requests", () => {
    const headers = { host: "sigde.example.org", "x-forwarded-proto": "https", ...tokenHeaders };
    expect(csrfOriginAllowed("POST", { ...headers, origin: "https://evil.example" })).toBe(false);
    expect(csrfOriginAllowed("POST", { host: "sigde.example.org", origin: "https://sigde.example.org" })).toBe(false);
    expect(csrfOriginAllowed("POST", { host: "sigde.example.org", "x-forwarded-proto": "https", origin: "https://sigde.example.org" })).toBe(false);
  });

  it("rejects mismatched and malformed CSRF tokens", () => {
    const headers = {
      ...tokenHeaders,
      host: "sigde.example.org",
      "x-forwarded-proto": "https",
      origin: "https://sigde.example.org",
    };
    expect(csrfOriginAllowed("POST", { ...headers, "x-sigde-csrf": "B".repeat(43) })).toBe(false);
    expect(csrfOriginAllowed("POST", { ...headers, cookie: "sigde_csrf=short" })).toBe(false);
  });

  it("supports same-origin Referer fallback and localhost HTTP", () => {
    expect(csrfOriginAllowed("POST", {
      ...tokenHeaders,
      host: "localhost:3000",
      referer: "http://localhost:3000/minha-senha",
    })).toBe(true);
    expect(csrfOriginAllowed("POST", {
      ...tokenHeaders,
      host: "localhost:3000",
      referer: "https://evil.example/form",
    })).toBe(false);
  });
});
