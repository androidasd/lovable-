import { randomBytes, timingSafeEqual } from "node:crypto";
import type { Request, Response } from "express";
import { getSessionCookieOptions } from "./cookies";

const CSRF_COOKIE_NAME = "sigde_csrf";
const CSRF_HEADER_NAME = "x-sigde-csrf";
const TOKEN_PATTERN = /^[A-Za-z0-9_-]{43}$/;
const CSRF_COOKIE_MAX_AGE_MS = 8 * 60 * 60 * 1000;

type HeaderValue = string | string[] | undefined;
type HeaderBag = Record<string, HeaderValue>;

function firstHeader(value: HeaderValue) {
  const first = Array.isArray(value) ? value[0] : value;
  return first?.split(",", 1)[0]?.trim();
}

function readCookie(headers: HeaderBag, cookieName: string) {
  const cookie = firstHeader(headers.cookie);
  if (!cookie) return undefined;
  for (const part of cookie.split(";")) {
    const index = part.indexOf("=");
    if (index < 0 || part.slice(0, index).trim() !== cookieName) continue;
    try {
      return decodeURIComponent(part.slice(index + 1).trim());
    } catch {
      return undefined;
    }
  }
  return undefined;
}

function tokenMatches(cookieToken: string | undefined, headerToken: string | undefined) {
  if (!cookieToken || !headerToken || !TOKEN_PATTERN.test(cookieToken) || !TOKEN_PATTERN.test(headerToken)) return false;
  const cookieBytes = Buffer.from(cookieToken, "utf8");
  const headerBytes = Buffer.from(headerToken, "utf8");
  return cookieBytes.length === headerBytes.length && timingSafeEqual(cookieBytes, headerBytes);
}

function originMatchesRequest(suppliedOrigin: string, headers: HeaderBag) {
  const host = firstHeader(headers.host);
  const forwardedHost = firstHeader(headers["x-forwarded-host"]);
  const publicHost = forwardedHost || host;
  if (!publicHost) return false;

  const forwardedProtocol = firstHeader(headers["x-forwarded-proto"])?.toLowerCase();
  const isLocalHost = /^(localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/i.test(publicHost);
  const protocol = forwardedProtocol === "http" || forwardedProtocol === "https"
    ? forwardedProtocol
    : isLocalHost ? "http" : "https";

  try {
    if (new URL(suppliedOrigin).origin === new URL(`${protocol}://${publicHost}`).origin) return true;
  } catch {
    return false;
  }

  // The Preview proxy rewrites the browser Origin to its loopback upstream origin.
  // Accept that alias only when the request also has a forwarded public HTTPS host;
  // a per-browser double-submit token is still mandatory below.
  const loopbackHost = host && /^(127\.0\.0\.1|localhost|\[::1\])(?::\d+)?$/i.test(host);
  const forwardedHttps = forwardedHost && forwardedProtocol === "https";
  if (!loopbackHost || !forwardedHttps) return false;
  try {
    return new URL(suppliedOrigin).origin === new URL(`http://${host}`).origin;
  } catch {
    return false;
  }
}

export function ensureCsrfCookie(req: Request, res: Response) {
  const existing = readCookie(req.headers, CSRF_COOKIE_NAME);
  if (existing && TOKEN_PATTERN.test(existing)) return;

  const token = randomBytes(32).toString("base64url");
  res.cookie(CSRF_COOKIE_NAME, token, {
    ...getSessionCookieOptions(req),
    httpOnly: false,
    maxAge: CSRF_COOKIE_MAX_AGE_MS,
  });
}

export function csrfOriginAllowed(method: string, headers: HeaderBag) {
  const normalizedMethod = method.toUpperCase();
  if (["GET", "HEAD", "OPTIONS"].includes(normalizedMethod)) return true;

  const originHeader = firstHeader(headers.origin);
  const refererHeader = firstHeader(headers.referer);
  let suppliedOrigin: string;
  try {
    suppliedOrigin = originHeader ? new URL(originHeader).origin : refererHeader ? new URL(refererHeader).origin : "";
  } catch {
    return false;
  }
  if (!suppliedOrigin || suppliedOrigin === "null") return false;
  if (!originMatchesRequest(suppliedOrigin, headers)) return false;

  return tokenMatches(readCookie(headers, CSRF_COOKIE_NAME), firstHeader(headers[CSRF_HEADER_NAME]));
}
