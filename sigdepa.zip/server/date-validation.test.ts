import { describe, expect, it } from "vitest";
import { isValidSchoolDate, schoolYearSchema } from "./date-validation";

describe("school date validation", () => {
  it("accepts actual calendar dates", () => {
    expect(isValidSchoolDate("2026-02-28")).toBe(true);
    expect(isValidSchoolDate("2024-02-29")).toBe(true);
  });

  it("rejects impossible or out-of-range dates", () => {
    expect(isValidSchoolDate("2026-02-31")).toBe(false);
    expect(isValidSchoolDate("2023-02-29")).toBe(false);
    expect(isValidSchoolDate("0000-01-01")).toBe(false);
    expect(isValidSchoolDate("2101-01-01")).toBe(false);
    expect(isValidSchoolDate("2026-13-01")).toBe(false);
  });

  it("validates school years as four-digit calendar years", () => {
    expect(schoolYearSchema.safeParse("2026").success).toBe(true);
    expect(schoolYearSchema.safeParse("0000").success).toBe(false);
    expect(schoolYearSchema.safeParse("2101").success).toBe(false);
  });
});
