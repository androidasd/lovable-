import { randomUUID } from "node:crypto";
import { and, desc, eq, inArray, lt, sql } from "drizzle-orm";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { BASE_DECLARATION_TEXT, COOKIE_NAME } from "@shared/const";
import { authBootstrap, authLoginAttempts, auditLogs, documentTemplates, institutions, localCredentials, users } from "../drizzle/schema";
import { getDb } from "./db";
import {
  clearFailedAttempts,
  dummyPasswordHash,
  hashPassword,
  isRateLimited,
  LOGIN_WINDOW_MS,
  makeAttemptKey,
  makeRateLimitBucket,
  MAX_LOGIN_FAILURES,
  normalizeEmail,
  recordFailedAttempt,
  safeCompareText,
  verifyPassword,
} from "./auth-credentials";
import { getSessionCookieOptions } from "./_core/cookies";
import { authenticatedProcedure, publicProcedure, router } from "./_core/trpc";
import { sdk } from "./_core/sdk";

const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const emailInput = z.string().trim().max(320).email().transform(normalizeEmail);
const passwordInput = z.string().min(12, "A senha precisa ter pelo menos 12 caracteres.").max(128);
const loginPasswordInput = z.string().min(1).max(128);

type Database = NonNullable<Awaited<ReturnType<typeof getDb>>>;

function getClientIp(req: { ip?: string; socket?: { remoteAddress?: string } }) {
  return req.ip || req.socket?.remoteAddress || "unknown";
}

function setSessionCookie(ctx: { req: Parameters<typeof getSessionCookieOptions>[0]; res: { cookie: (name: string, value: string, options: Record<string, unknown>) => unknown } }, token: string) {
  ctx.res.cookie(COOKIE_NAME, token, { ...getSessionCookieOptions(ctx.req), maxAge: SESSION_TTL_MS });
}

async function isPersistentlyRateLimited(db: Database, buckets: string[]) {
  const records = await db.select({ count: authLoginAttempts.count, startedAt: authLoginAttempts.windowStartedAt })
    .from(authLoginAttempts).where(inArray(authLoginAttempts.bucket, buckets));
  const now = Date.now();
  return records.some(record => record.count >= MAX_LOGIN_FAILURES && now - new Date(record.startedAt).getTime() < LOGIN_WINDOW_MS);
}

async function recordPersistentFailure(db: Database, bucket: string) {
  const now = new Date();
  const cutoff = new Date(now.getTime() - LOGIN_WINDOW_MS);
  await db.insert(authLoginAttempts).values({ bucket, count: 1, windowStartedAt: now }).onDuplicateKeyUpdate({ set: {
    count: sql`IF(${authLoginAttempts.windowStartedAt} <= ${cutoff}, 1, ${authLoginAttempts.count} + 1)`,
    windowStartedAt: sql`IF(${authLoginAttempts.windowStartedAt} <= ${cutoff}, ${now}, ${authLoginAttempts.windowStartedAt})`,
    updatedAt: now,
  } });
  if (Math.random() < 0.02) await db.delete(authLoginAttempts).where(lt(authLoginAttempts.windowStartedAt, cutoff));
}

async function clearPersistentFailures(db: Database, buckets: string[]) {
  await db.delete(authLoginAttempts).where(inArray(authLoginAttempts.bucket, buckets));
}

export const authRouter = router({
  me: publicProcedure.query(({ ctx }) => ctx.user),

  bootstrapStatus: publicProcedure.query(async () => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível." });
    const [state] = await db.select().from(authBootstrap).where(eq(authBootstrap.id, 1)).limit(1);
    const [administrator] = await db.select({ id: users.id }).from(localCredentials)
      .innerJoin(users, eq(localCredentials.userId, users.id))
      .where(eq(users.role, "admin")).limit(1);
    return {
      needsSetup: !state?.completed && !administrator,
      tokenConfigured: (process.env.SIGDE_BOOTSTRAP_TOKEN?.length ?? 0) >= 24,
    };
  }),

  login: publicProcedure.input(z.object({ email: emailInput, password: loginPasswordInput })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível." });
    const ip = getClientIp(ctx.req);
    const localKey = makeAttemptKey(ip, input.email);
    const buckets = [makeRateLimitBucket("ip", ip), makeRateLimitBucket("email", input.email)];
    if (isRateLimited(localKey) || await isPersistentlyRateLimited(db, buckets)) {
      throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Muitas tentativas. Aguarde alguns minutos e tente novamente." });
    }

    const [account] = await db.select({
      id: users.id,
      openId: users.openId,
      name: users.name,
      sessionVersion: users.sessionVersion,
      hash: localCredentials.passwordHash,
    }).from(localCredentials).innerJoin(users, eq(localCredentials.userId, users.id))
      .where(eq(localCredentials.emailNormalized, input.email)).limit(1);
    const passwordMatches = await verifyPassword(input.password, account?.hash ?? dummyPasswordHash);
    if (!account || !passwordMatches) {
      recordFailedAttempt(localKey);
      for (const bucket of buckets) await recordPersistentFailure(db, bucket);
      throw new TRPCError({ code: "UNAUTHORIZED", message: "E-mail ou senha inválidos." });
    }

    clearFailedAttempts(localKey);
    await clearPersistentFailures(db, buckets);
    await db.update(users).set({ lastSignedIn: new Date() }).where(eq(users.id, account.id));
    const token = await sdk.createSessionToken(account.openId, {
      name: account.name || input.email,
      expiresInMs: SESSION_TTL_MS,
      sessionVersion: account.sessionVersion,
    });
    setSessionCookie(ctx, token);
    return { success: true };
  }),

  bootstrap: publicProcedure.input(z.object({
    token: z.string().min(24).max(256),
    name: z.string().trim().min(2).max(240),
    email: emailInput,
    password: passwordInput,
  })).mutation(async ({ ctx, input }) => {
    const expectedToken = process.env.SIGDE_BOOTSTRAP_TOKEN;
    if (!expectedToken || expectedToken.length < 24) {
      throw new TRPCError({ code: "PRECONDITION_FAILED", message: "A configuração inicial ainda não foi habilitada com um token válido." });
    }
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível." });
    const ip = getClientIp(ctx.req);
    const localKey = makeAttemptKey(ip, "bootstrap");
    const buckets = [makeRateLimitBucket("bootstrap-ip", ip)];
    if (isRateLimited(localKey) || await isPersistentlyRateLimited(db, buckets)) {
      throw new TRPCError({ code: "TOO_MANY_REQUESTS", message: "Muitas tentativas. Aguarde e tente novamente." });
    }
    if (!safeCompareText(input.token, expectedToken)) {
      recordFailedAttempt(localKey);
      for (const bucket of buckets) await recordPersistentFailure(db, bucket);
      throw new TRPCError({ code: "UNAUTHORIZED", message: "Não foi possível validar a configuração inicial." });
    }
    clearFailedAttempts(localKey);
    await clearPersistentFailures(db, buckets);

    const encodedPassword = await hashPassword(input.password);
    let accountOpenId = "";
    let accountSessionVersion = 0;
    await db.transaction(async tx => {
      const [state] = await tx.select().from(authBootstrap).where(eq(authBootstrap.id, 1)).for("update").limit(1);
      if (!state) throw new TRPCError({ code: "PRECONDITION_FAILED", message: "A migração de autenticação inicial ainda não foi aplicada." });
      const [existingAdministrator] = await tx.select({ id: users.id }).from(localCredentials)
        .innerJoin(users, eq(localCredentials.userId, users.id)).where(eq(users.role, "admin")).limit(1);
      if (state.completed || existingAdministrator) throw new TRPCError({ code: "CONFLICT", message: "A configuração inicial já foi concluída." });

      const matchingUsers = await tx.select({ id: users.id, openId: users.openId, sessionVersion: users.sessionVersion }).from(users)
        .where(sql`LOWER(${users.email}) = ${input.email}`).limit(2);
      if (matchingUsers.length > 1) {
        throw new TRPCError({ code: "CONFLICT", message: "Há mais de uma conta institucional com este e-mail. Solicite revisão ao responsável pelo sistema." });
      }

      let userId: number;
      if (matchingUsers.length === 1) {
        userId = matchingUsers[0].id;
        accountOpenId = matchingUsers[0].openId;
        accountSessionVersion = matchingUsers[0].sessionVersion + 1;
        await tx.update(users).set({
          name: input.name,
          email: input.email,
          loginMethod: "email-password",
          role: "admin",
          lastSignedIn: new Date(),
          sessionVersion: accountSessionVersion,
        }).where(eq(users.id, userId));
      } else {
        accountOpenId = `local_${randomUUID()}`;
        const result = await tx.insert(users).values({
          openId: accountOpenId,
          name: input.name,
          email: input.email,
          loginMethod: "email-password",
          role: "admin",
          institutionId: 1,
          lastSignedIn: new Date(),
        });
        userId = Number(result[0].insertId);
      }

      const [emailOwner] = await tx.select({ userId: localCredentials.userId }).from(localCredentials)
        .where(eq(localCredentials.emailNormalized, input.email)).limit(1);
      if (emailOwner && emailOwner.userId !== userId) {
        throw new TRPCError({ code: "CONFLICT", message: "Este e-mail já está associado a outra conta local." });
      }
      const [currentCredential] = await tx.select({ id: localCredentials.id }).from(localCredentials)
        .where(eq(localCredentials.userId, userId)).limit(1);
      if (currentCredential) {
        await tx.update(localCredentials).set({ emailNormalized: input.email, passwordHash: encodedPassword })
          .where(eq(localCredentials.userId, userId));
      } else {
        await tx.insert(localCredentials).values({ userId, emailNormalized: input.email, passwordHash: encodedPassword });
      }

      await tx.insert(institutions).values({ id: 1, name: "COLÉGIO ESTADUAL DE ENSINO MÉDIO ROSA ALVAREZ REBELO" })
        .onDuplicateKeyUpdate({ set: { name: sql`${institutions.name}` } });
      const [activeTemplate] = await tx.select({ id: documentTemplates.id }).from(documentTemplates)
        .where(and(eq(documentTemplates.institutionId, 1), eq(documentTemplates.active, true))).limit(1);
      if (!activeTemplate) {
        const [existingTemplate] = await tx.select({ id: documentTemplates.id }).from(documentTemplates)
          .where(eq(documentTemplates.institutionId, 1)).orderBy(desc(documentTemplates.id)).limit(1);
        if (existingTemplate) {
          await tx.update(documentTemplates).set({ active: true }).where(eq(documentTemplates.id, existingTemplate.id));
        } else {
          await tx.insert(documentTemplates).values({
            institutionId: 1,
            name: "Declaração de Escolaridade",
            content: BASE_DECLARATION_TEXT,
            version: 1,
            active: true,
            createdBy: userId,
          });
        }
      }
      await tx.insert(auditLogs).values({
        institutionId: 1,
        actorId: userId,
        action: "auth.bootstrap",
        entityType: "usuario",
        entityId: String(userId),
        details: { method: "email-password" },
      });
      await tx.update(authBootstrap).set({ completed: true }).where(eq(authBootstrap.id, 1));
    });

    const session = await sdk.createSessionToken(accountOpenId, {
      name: input.name,
      expiresInMs: SESSION_TTL_MS,
      sessionVersion: accountSessionVersion,
    });
    setSessionCookie(ctx, session);
    return { success: true };
  }),

  changePassword: authenticatedProcedure.input(z.object({ currentPassword: loginPasswordInput, newPassword: passwordInput })).mutation(async ({ ctx, input }) => {
    const db = await getDb();
    if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível." });
    const [credential] = await db.select({ id: localCredentials.id, hash: localCredentials.passwordHash }).from(localCredentials)
      .where(eq(localCredentials.userId, ctx.user.id)).limit(1);
    if (!credential || !(await verifyPassword(input.currentPassword, credential.hash))) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "A senha atual está incorreta ou a conta precisa ser provisionada por um Administrador." });
    }
    if (await verifyPassword(input.newPassword, credential.hash)) {
      throw new TRPCError({ code: "BAD_REQUEST", message: "Escolha uma senha diferente da atual." });
    }
    const newHash = await hashPassword(input.newPassword);
    let sessionVersion = ctx.user.sessionVersion;
    await db.transaction(async tx => {
      await tx.update(localCredentials).set({ passwordHash: newHash }).where(eq(localCredentials.id, credential.id));
      await tx.update(users).set({ sessionVersion: sql`${users.sessionVersion} + 1` }).where(eq(users.id, ctx.user.id));
      const [updatedUser] = await tx.select({ sessionVersion: users.sessionVersion }).from(users)
        .where(eq(users.id, ctx.user.id)).limit(1);
      if (!updatedUser) throw new TRPCError({ code: "NOT_FOUND", message: "Usuário não encontrado." });
      sessionVersion = updatedUser.sessionVersion;
    });
    const renewedSession = await sdk.createSessionToken(ctx.user.openId, {
      name: ctx.user.name ?? "",
      expiresInMs: SESSION_TTL_MS,
      sessionVersion,
    });
    setSessionCookie(ctx, renewedSession);
    return { success: true };
  }),

  logout: publicProcedure.mutation(({ ctx }) => {
    const options = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...options, maxAge: -1 });
    return { success: true } as const;
  }),
});
