import { and, asc, count, desc, eq, like, or, sql } from "drizzle-orm";
import { randomUUID } from "node:crypto";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { normalizeDeclarationTemplateContent } from "@shared/const";
import {
  auditLogs,
  declarations,
  documentSequences,
  documentTemplates,
  enrollments,
  localCredentials,
  institutions,
  schoolClasses,
  students,
  users,
} from "../drizzle/schema";
import { getDb } from "./db";
import { hashPassword, normalizeEmail } from "./auth-credentials";
import { schoolDateSchema, schoolYearSchema } from "./date-validation";
import { adminProcedure, protectedProcedure, router, secretariaProcedure } from "./_core/trpc";

const shift = z.enum(["MANHÃ", "TARDE", "NOITE", "INTEGRAL"]);
const enrollmentStatus = z.enum(["ATIVA", "INATIVA", "TRANSFERIDA", "CONCLUÍDA"]);
const role = z.enum(["admin", "secretaria", "consulta"]);

const studentInput = z.object({
  fullName: z.string().trim().min(3).max(240),
  birthDate: schoolDateSchema,
  motherName: z.string().trim().min(2).max(240),
  fatherName: z.string().trim().max(240).nullable().optional(),
  guardianName: z.string().trim().max(240).nullable().optional(),
  enrollmentNumber: z.string().trim().min(1).max(80),
  schoolYear: schoolYearSchema,
  grade: z.string().trim().min(1).max(80),
  className: z.string().trim().min(1).max(100),
  shift,
  modality: z.string().trim().min(1).max(120),
  enrollmentStatus,
});

type StudentPayload = z.infer<typeof studentInput>;
type DrizzleExecutor = Pick<NonNullable<Awaited<ReturnType<typeof getDb>>>, "insert" | "select">;

async function ensureEnrollment(executor: DrizzleExecutor, studentId: number, data: StudentPayload, actorId: number) {
  await executor.insert(schoolClasses).values({
    institutionId: 1,
    schoolYear: data.schoolYear,
    grade: data.grade,
    name: data.className,
    shift: data.shift,
  }).onDuplicateKeyUpdate({ set: { active: true } });
  const [schoolClass] = await executor.select({ id: schoolClasses.id }).from(schoolClasses).where(and(
    eq(schoolClasses.institutionId, 1),
    eq(schoolClasses.schoolYear, data.schoolYear),
    eq(schoolClasses.grade, data.grade),
    eq(schoolClasses.name, data.className),
    eq(schoolClasses.shift, data.shift),
  )).limit(1);
  if (!schoolClass) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Não foi possível relacionar a matrícula à turma." });
  await executor.insert(enrollments).values({
    institutionId: 1,
    studentId,
    classId: schoolClass.id,
    enrollmentNumber: data.enrollmentNumber,
    schoolYear: data.schoolYear,
    modality: data.modality,
    status: data.enrollmentStatus,
    createdBy: actorId,
  }).onDuplicateKeyUpdate({ set: {
    classId: schoolClass.id,
    enrollmentNumber: data.enrollmentNumber,
    modality: data.modality,
    status: data.enrollmentStatus,
  } });
}

const settingsInput = z.object({
  name: z.string().trim().min(2).max(240),
  government: z.string().trim().min(2).max(240),
  secretary: z.string().trim().min(2).max(240),
  regionalOffice: z.string().trim().min(2).max(240),
  address: z.string().trim().min(2).max(320),
  municipality: z.string().trim().min(2).max(160),
  state: z.string().trim().min(2).max(80),
  phone: z.string().trim().max(80),
  inepCode: z.string().trim().max(40),
  authorizationAct: z.string().trim().max(240),
  logoData: z.string().max(2_000_000).nullable(),
  signatureData: z.string().max(2_000_000).nullable(),
  signerName: z.string().trim().max(240),
  signerRole: z.string().trim().max(160),
});

const documentInput = z.object({
  studentId: z.number().int().positive().nullable().optional(),
  fullName: z.string().trim().min(3).max(240),
  birthDate: schoolDateSchema,
  motherName: z.string().trim().max(240),
  fatherName: z.string().trim().max(240).nullable().optional(),
  guardianName: z.string().trim().max(240).nullable().optional(),
  schoolYear: schoolYearSchema,
  grade: z.string().trim().min(1).max(80),
  className: z.string().trim().min(1).max(100),
  shift,
  modality: z.string().trim().min(1).max(120).default("Ensino Médio (SOME REGULAR)"),
  issuedAt: schoolDateSchema,
  signerName: z.string().trim().min(2).max(240),
  signerRole: z.string().trim().max(160),
  templateId: z.number().int().positive().nullable().optional(),
}).refine(input => Boolean(input.motherName.trim() || input.guardianName?.trim()), {
  message: "Informe o nome da mãe ou do responsável legal.",
  path: ["motherName"],
});

async function database() {
  const db = await getDb();
  if (!db) throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "Banco de dados indisponível. Verifique a configuração do servidor." });
  return db;
}

async function audit(actorId: number, action: string, entityType: string, entityId?: string | number, details?: Record<string, unknown>, executor?: DrizzleExecutor) {
  const db = executor ?? await database();
  await db.insert(auditLogs).values({
    institutionId: 1,
    actorId,
    action,
    entityType,
    entityId: entityId == null ? null : String(entityId),
    details: details ?? null,
  });
}

export const sigdeRouter = router({
  dashboard: protectedProcedure.query(async () => {
    const db = await database();
    const [studentCount] = await db.select({ value: count() }).from(students).where(eq(students.institutionId, 1));
    const [declarationCount] = await db.select({ value: count() }).from(declarations).where(eq(declarations.institutionId, 1));
    const [monthCount] = await db.select({ value: count() }).from(declarations).where(and(
      eq(declarations.institutionId, 1),
      sql`YEAR(${declarations.issuedAt}) = YEAR(CURRENT_DATE()) AND MONTH(${declarations.issuedAt}) = MONTH(CURRENT_DATE())`,
      eq(declarations.status, "EMITIDA"),
    ));
    const grades = await db.select({ grade: students.grade, total: count() }).from(students)
      .where(and(eq(students.institutionId, 1), eq(students.enrollmentStatus, "ATIVA")))
      .groupBy(students.grade).orderBy(asc(students.grade));
    const recent = await db.select({
      id: declarations.id,
      documentNumber: declarations.documentNumber,
      issuedAt: declarations.issuedAt,
      status: declarations.status,
      fullName: sql<string | null>`COALESCE(${students.fullName}, JSON_UNQUOTE(JSON_EXTRACT(${declarations.snapshot}, '$.fullName')))` ,
      grade: sql<string | null>`COALESCE(${students.grade}, JSON_UNQUOTE(JSON_EXTRACT(${declarations.snapshot}, '$.grade')))` ,
      issuerName: users.name,
    }).from(declarations)
      .leftJoin(students, eq(declarations.studentId, students.id))
      .leftJoin(users, eq(declarations.createdBy, users.id))
      .where(eq(declarations.institutionId, 1))
      .orderBy(desc(declarations.createdAt)).limit(6);
    return { totalStudents: studentCount?.value ?? 0, totalDeclarations: declarationCount?.value ?? 0, issuedThisMonth: monthCount?.value ?? 0, grades, recent };
  }),

  students: router({
    list: protectedProcedure.input(z.object({
      search: z.string().trim().max(120).optional(),
      grade: z.string().optional(),
      className: z.string().optional(),
      shift: shift.optional(),
      status: enrollmentStatus.optional(),
      limit: z.number().int().min(1).max(250).default(150),
    }).optional()).query(async ({ input }) => {
      const db = await database();
      const filters = [eq(students.institutionId, 1)];
      if (input?.search) filters.push(or(like(students.fullName, `%${input.search}%`), like(students.enrollmentNumber, `%${input.search}%`))!);
      if (input?.grade) filters.push(eq(students.grade, input.grade));
      if (input?.className) filters.push(eq(students.className, input.className));
      if (input?.shift) filters.push(eq(students.shift, input.shift));
      if (input?.status) filters.push(eq(students.enrollmentStatus, input.status));
      return db.select().from(students).where(and(...filters)).orderBy(asc(students.fullName)).limit(input?.limit ?? 150);
    }),
    save: secretariaProcedure.input(studentInput.extend({ id: z.number().int().positive().optional() })).mutation(async ({ ctx, input }) => {
      const db = await database();
      const { id, ...data } = input;
      if (id) {
        const existing = await db.select({ id: students.id }).from(students).where(and(eq(students.id, id), eq(students.institutionId, 1))).limit(1);
        if (!existing.length) throw new TRPCError({ code: "NOT_FOUND", message: "Aluno não encontrado." });
        await db.transaction(async tx => {
          await tx.update(students).set(data).where(eq(students.id, id));
          await ensureEnrollment(tx, id, data, ctx.user.id);
          await audit(ctx.user.id, "aluno.editado", "aluno", id, undefined, tx);
        });
        return { id, duplicateWarning: false };
      }
      const possibleDuplicates = await db.select({ id: students.id }).from(students).where(and(
        eq(students.institutionId, 1), eq(students.fullName, data.fullName), eq(students.birthDate, data.birthDate),
      )).limit(5);
      const studentId = await db.transaction(async tx => {
        const result = await tx.insert(students).values({ ...data, institutionId: 1, createdBy: ctx.user.id });
        const newStudentId = Number(result[0].insertId);
        await ensureEnrollment(tx, newStudentId, data, ctx.user.id);
        await audit(ctx.user.id, "aluno.cadastrado", "aluno", newStudentId, { possibleDuplicateCount: possibleDuplicates.length }, tx);
        return newStudentId;
      });
      return { id: studentId, duplicateWarning: possibleDuplicates.length > 0 };
    }),
    importMany: secretariaProcedure.input(z.object({ rows: z.array(studentInput).min(1).max(500) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      return db.transaction(async tx => {
        const inserted: number[] = [];
        const skipped: Array<{ row: number; reason: string }> = [];
        for (let i = 0; i < input.rows.length; i++) {
          const row = input.rows[i];
          const duplicate = await tx.select({ id: students.id }).from(students).where(and(
            eq(students.institutionId, 1), eq(students.enrollmentNumber, row.enrollmentNumber), eq(students.schoolYear, row.schoolYear),
          )).limit(1);
          if (duplicate.length) { skipped.push({ row: i + 2, reason: "Matrícula e ano letivo já cadastrados." }); continue; }
          const possibleName = await tx.select({ id: students.id }).from(students).where(and(
            eq(students.institutionId, 1), eq(students.fullName, row.fullName), eq(students.birthDate, row.birthDate),
          )).limit(1);
          if (possibleName.length) { skipped.push({ row: i + 2, reason: "Possível duplicidade por nome e nascimento; confira o cadastro." }); continue; }
          const result = await tx.insert(students).values({ ...row, institutionId: 1, createdBy: ctx.user.id });
          const newStudentId = Number(result[0].insertId);
          await ensureEnrollment(tx, newStudentId, row, ctx.user.id);
          inserted.push(newStudentId);
        }
        await audit(ctx.user.id, "alunos.importados", "aluno", undefined, { importedCount: inserted.length, skippedCount: skipped.length }, tx);
        return { importedCount: inserted.length, skipped };
      });
    }),
    inactivate: secretariaProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx => {
        const result = await tx.update(students).set({ enrollmentStatus: "INATIVA" }).where(and(eq(students.id, input.id), eq(students.institutionId, 1)));
        if (!result[0].affectedRows) throw new TRPCError({ code: "NOT_FOUND", message: "Aluno não encontrado." });
        await tx.update(enrollments).set({ status: "INATIVA" }).where(and(eq(enrollments.studentId, input.id), eq(enrollments.institutionId, 1), eq(enrollments.status, "ATIVA")));
        await audit(ctx.user.id, "aluno.inativado", "aluno", input.id, undefined, tx);
      });
      return { success: true };
    }),
    classes: protectedProcedure.query(async () => {
      const db = await database();
      return db.select().from(schoolClasses).where(and(eq(schoolClasses.institutionId, 1), eq(schoolClasses.active, true))).orderBy(desc(schoolClasses.schoolYear), asc(schoolClasses.grade), asc(schoolClasses.name));
    }),
  }),

  declarations: router({
    nextNumber: protectedProcedure.input(z.object({ year: z.number().int().min(2000).max(2200).optional() }).optional()).query(async ({ input }) => {
      const db = await database();
      const year = input?.year ?? new Date().getFullYear();
      const [sequence] = await db.select({ lastNumber: documentSequences.lastNumber }).from(documentSequences).where(eq(documentSequences.year, year)).limit(1);
      const next = (sequence?.lastNumber ?? 0) + 1;
      return { year, number: `${year}/${String(next).padStart(4, "0")}` };
    }),
    create: secretariaProcedure.input(documentInput).mutation(async ({ ctx, input }) => {
      const db = await database();
      if (input.studentId) {
        const [existing] = await db.select().from(students).where(and(eq(students.id, input.studentId), eq(students.institutionId, 1))).limit(1);
        if (!existing || existing.enrollmentStatus !== "ATIVA") throw new TRPCError({ code: "BAD_REQUEST", message: "O cadastro do aluno não está ativo. Confira os dados antes de emitir." });
        const [currentEnrollment] = await db.select({
          schoolYear: enrollments.schoolYear,
          grade: schoolClasses.grade,
          className: schoolClasses.name,
          shift: schoolClasses.shift,
          modality: enrollments.modality,
        }).from(enrollments).innerJoin(schoolClasses, eq(enrollments.classId, schoolClasses.id)).where(and(
          eq(enrollments.studentId, input.studentId),
          eq(enrollments.institutionId, 1),
          eq(enrollments.status, "ATIVA"),
          eq(enrollments.schoolYear, input.schoolYear),
          eq(schoolClasses.institutionId, 1),
          eq(schoolClasses.active, true),
        )).limit(1);
        if (!currentEnrollment) throw new TRPCError({ code: "BAD_REQUEST", message: "O aluno não possui matrícula ativa para o ano letivo informado." });
        const studentMatches = input.fullName === existing.fullName
          && input.birthDate === existing.birthDate
          && input.motherName === existing.motherName
          && (input.fatherName ?? "") === (existing.fatherName ?? "")
          && (input.guardianName ?? "") === (existing.guardianName ?? "");
        const enrollmentMatches = input.schoolYear === currentEnrollment.schoolYear
          && input.grade === currentEnrollment.grade
          && input.className === currentEnrollment.className
          && input.shift === currentEnrollment.shift
          && input.modality === currentEnrollment.modality;
        if (!studentMatches || !enrollmentMatches) throw new TRPCError({ code: "BAD_REQUEST", message: "Os dados da declaração divergem do cadastro selecionado. Desvincule o cadastro para emitir manualmente ou selecione novamente o aluno." });
      }
      const [institution] = await db.select().from(institutions).where(eq(institutions.id, 1)).limit(1);
      const templateQuery = input.templateId
        ? await db.select().from(documentTemplates).where(and(eq(documentTemplates.id, input.templateId), eq(documentTemplates.institutionId, 1), eq(documentTemplates.active, true))).limit(1)
        : await db.select().from(documentTemplates).where(and(eq(documentTemplates.institutionId, 1), eq(documentTemplates.active, true))).orderBy(desc(documentTemplates.id)).limit(1);
      const template = templateQuery[0];
      if (input.templateId && !template) throw new TRPCError({ code: "BAD_REQUEST", message: "O modelo selecionado está inativo ou não está disponível." });
      const snapshot = {
        fullName: input.fullName,
        birthDate: input.birthDate,
        motherName: input.motherName,
        fatherName: input.fatherName ?? "",
        guardianName: input.guardianName ?? "",
        schoolYear: input.schoolYear,
        grade: input.grade,
        className: input.className,
        shift: input.shift,
        modality: input.modality,
        issuedAt: input.issuedAt,
        signerName: input.signerName,
        signerRole: input.signerRole,
        institution: institution ?? null,
        templateContent: normalizeDeclarationTemplateContent(template?.content),
        templateVersion: template?.version ?? 1,
      };
      const year = Number(input.issuedAt.slice(0, 4));
      const saved = await db.transaction(async (tx) => {
        await tx.insert(documentSequences).values({ year, lastNumber: 1 }).onDuplicateKeyUpdate({
          set: { lastNumber: sql`${documentSequences.lastNumber} + 1`, updatedAt: new Date() },
        });
        const [seq] = await tx.select({ lastNumber: documentSequences.lastNumber }).from(documentSequences).where(eq(documentSequences.year, year)).limit(1);
        const sequenceNumber = Number(seq?.lastNumber ?? 1);
        const documentNumber = `${year}/${String(sequenceNumber).padStart(4, "0")}`;
        const result = await tx.insert(declarations).values({
          institutionId: 1,
          studentId: input.studentId ?? null,
          documentNumber,
          sequenceYear: year,
          sequenceNumber,
          issuedAt: input.issuedAt,
          signerName: input.signerName,
          signerRole: input.signerRole,
          snapshot,
          templateVersion: Number(template?.version ?? 1),
          status: "EMITIDA",
          createdBy: ctx.user.id,
        });
        const savedDocument = { id: Number(result[0].insertId), documentNumber };
        await audit(ctx.user.id, "declaracao.emitida", "declaracao", savedDocument.id, { documentNumber }, tx);
        return savedDocument;
      });
      return saved;
    }),
    list: protectedProcedure.input(z.object({ search: z.string().trim().max(120).optional(), from: schoolDateSchema.optional(), to: schoolDateSchema.optional(), status: z.enum(["EMITIDA", "CANCELADA"]).optional() }).optional()).query(async ({ input }) => {
      const db = await database();
      const filters = [eq(declarations.institutionId, 1)];
      const snapshotName = sql<string | null>`JSON_UNQUOTE(JSON_EXTRACT(${declarations.snapshot}, '$.fullName'))`;
      if (input?.search) filters.push(or(like(students.fullName, `%${input.search}%`), like(snapshotName, `%${input.search}%`), like(declarations.documentNumber, `%${input.search}%`))!);
      if (input?.status) filters.push(eq(declarations.status, input.status));
      if (input?.from) filters.push(sql`${declarations.issuedAt} >= ${input.from}`);
      if (input?.to) filters.push(sql`${declarations.issuedAt} <= ${input.to}`);
      const rows = await db.select({
        id: declarations.id,
        documentNumber: declarations.documentNumber,
        issuedAt: declarations.issuedAt,
        status: declarations.status,
        studentId: declarations.studentId,
        fullName: sql<string | null>`COALESCE(${students.fullName}, JSON_UNQUOTE(JSON_EXTRACT(${declarations.snapshot}, '$.fullName')))` ,
        grade: sql<string | null>`COALESCE(${students.grade}, JSON_UNQUOTE(JSON_EXTRACT(${declarations.snapshot}, '$.grade')))` ,
        issuerName: users.name,
        createdAt: declarations.createdAt,
      }).from(declarations)
        .leftJoin(students, eq(declarations.studentId, students.id))
        .leftJoin(users, eq(declarations.createdBy, users.id))
        .where(and(...filters)).orderBy(desc(declarations.createdAt)).limit(250);
      return rows;
    }),
    get: protectedProcedure.input(z.object({ id: z.number().int().positive() })).query(async ({ input }) => {
      const db = await database();
      const [row] = await db.select().from(declarations).where(and(eq(declarations.id, input.id), eq(declarations.institutionId, 1))).limit(1);
      if (!row) throw new TRPCError({ code: "NOT_FOUND", message: "Declaração não encontrada." });
      return row;
    }),
    cancel: secretariaProcedure.input(z.object({ id: z.number().int().positive(), reason: z.string().trim().min(5).max(1000) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx => {
        const result = await tx.update(declarations).set({ status: "CANCELADA", cancellationReason: input.reason }).where(and(
          eq(declarations.id, input.id), eq(declarations.institutionId, 1), eq(declarations.status, "EMITIDA"),
        ));
        if (!result[0].affectedRows) throw new TRPCError({ code: "NOT_FOUND", message: "A declaração não está disponível para cancelamento." });
        await audit(ctx.user.id, "declaracao.cancelada", "declaracao", input.id, { reason: input.reason }, tx);
      });
      return { success: true };
    }),
  }),

  settings: router({
    get: adminProcedure.query(async () => {
      const db = await database();
      const [settings] = await db.select().from(institutions).where(eq(institutions.id, 1)).limit(1);
      return settings ?? null;
    }),
    forEmission: secretariaProcedure.query(async () => {
      const db = await database();
      const [settings] = await db.select({
        name: institutions.name, government: institutions.government, secretary: institutions.secretary,
        regionalOffice: institutions.regionalOffice, address: institutions.address, municipality: institutions.municipality,
        state: institutions.state, phone: institutions.phone, inepCode: institutions.inepCode,
        authorizationAct: institutions.authorizationAct, logoData: institutions.logoData,
        signatureData: institutions.signatureData, signerName: institutions.signerName, signerRole: institutions.signerRole,
      }).from(institutions).where(eq(institutions.id, 1)).limit(1);
      return settings ?? null;
    }),
    save: adminProcedure.input(settingsInput).mutation(async ({ ctx, input }) => {
      const db = await database();
      await db.transaction(async tx => {
        await tx.update(institutions).set(input).where(eq(institutions.id, 1));
        await audit(ctx.user.id, "escola.configurada", "instituicao", 1, undefined, tx);
      });
      const [settings] = await db.select().from(institutions).where(eq(institutions.id, 1)).limit(1);
      return settings;
    }),
  }),

  templates: router({
    list: adminProcedure.query(async () => {
      const db = await database();
      const templates = await db.select().from(documentTemplates).where(eq(documentTemplates.institutionId, 1)).orderBy(desc(documentTemplates.id));
      return templates.map(template => ({ ...template, content: normalizeDeclarationTemplateContent(template.content) }));
    }),
    activeForEmission: secretariaProcedure.query(async () => {
      const db = await database();
      const templates = await db.select({ id: documentTemplates.id, name: documentTemplates.name, content: documentTemplates.content, version: documentTemplates.version, active: documentTemplates.active })
        .from(documentTemplates).where(and(eq(documentTemplates.institutionId, 1), eq(documentTemplates.active, true))).orderBy(desc(documentTemplates.id)).limit(1);
      return templates.map(template => ({ ...template, content: normalizeDeclarationTemplateContent(template.content) }));
    }),
    save: adminProcedure.input(z.object({ name: z.string().trim().min(2).max(160), content: z.string().trim().min(30).max(8000) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      return db.transaction(async tx => {
        const [latest] = await tx.select().from(documentTemplates).where(and(eq(documentTemplates.institutionId, 1), eq(documentTemplates.name, input.name))).orderBy(desc(documentTemplates.version)).limit(1);
        const version = (latest?.version ?? 0) + 1;
        const result = await tx.insert(documentTemplates).values({ institutionId: 1, name: input.name, content: input.content, version, active: true, createdBy: ctx.user.id });
        if (latest) await tx.update(documentTemplates).set({ active: false }).where(eq(documentTemplates.id, latest.id));
        const id = Number(result[0].insertId);
        await audit(ctx.user.id, "modelo.atualizado", "modelo", id, { name: input.name, version }, tx);
        return { id, version };
      });
    }),
  }),

  users: router({
    list: adminProcedure.query(async () => {
      const db = await database();
      return db.select({
        id: users.id,
        name: users.name,
        email: users.email,
        role: users.role,
        lastSignedIn: users.lastSignedIn,
        createdAt: users.createdAt,
        hasPassword: sql<boolean>`CASE WHEN ${localCredentials.id} IS NULL THEN FALSE ELSE TRUE END`,
      }).from(users).leftJoin(localCredentials, eq(users.id, localCredentials.userId))
        .where(eq(users.institutionId, 1)).orderBy(asc(users.name));
    }),
    createAccount: adminProcedure.input(z.object({
      name: z.string().trim().min(2).max(240),
      email: z.string().trim().email().max(320),
      password: z.string().min(12).max(128),
      role: z.enum(["user", "admin", "secretaria", "consulta"]),
    })).mutation(async ({ ctx, input }) => {
      const db = await database();
      const emailNormalized = normalizeEmail(input.email);
      const passwordHash = await hashPassword(input.password);
      return db.transaction(async tx => {
        const [existingEmail] = await tx.select({ userId: localCredentials.userId }).from(localCredentials)
          .where(eq(localCredentials.emailNormalized, emailNormalized)).limit(1);
        if (existingEmail) throw new TRPCError({ code: "CONFLICT", message: "Já existe uma conta local com este e-mail." });
        const matchingUsers = await tx.select({ id: users.id }).from(users)
          .where(sql`LOWER(${users.email}) = ${emailNormalized}`).limit(2);
        if (matchingUsers.length > 1) throw new TRPCError({ code: "CONFLICT", message: "Há mais de uma conta institucional com este e-mail." });
        let userId: number;
        if (matchingUsers.length === 1) {
          userId = matchingUsers[0].id;
          const [existingCredential] = await tx.select({ id: localCredentials.id }).from(localCredentials)
            .where(eq(localCredentials.userId, userId)).limit(1);
          if (existingCredential) throw new TRPCError({ code: "CONFLICT", message: "Esta conta já possui senha local. Use a redefinição de senha." });
          await tx.update(users).set({ name: input.name, email: emailNormalized, loginMethod: "email-password", role: input.role, sessionVersion: sql`${users.sessionVersion} + 1` }).where(eq(users.id, userId));
        } else {
          const openId = `local_${randomUUID()}`;
          const result = await tx.insert(users).values({
            openId,
            name: input.name,
            email: emailNormalized,
            loginMethod: "email-password",
            role: input.role,
            institutionId: 1,
          });
          userId = Number(result[0].insertId);
        }
        await tx.insert(localCredentials).values({ userId, emailNormalized, passwordHash });
        await audit(ctx.user.id, "usuario.criado", "usuario", userId, { role: input.role }, tx);
        return { id: userId };
      });
    }),
    setPassword: adminProcedure.input(z.object({ id: z.number().int().positive(), password: z.string().min(12).max(128) })).mutation(async ({ ctx, input }) => {
      const db = await database();
      const passwordHash = await hashPassword(input.password);
      await db.transaction(async tx => {
        const [target] = await tx.select({ id: users.id, email: users.email }).from(users)
          .where(and(eq(users.id, input.id), eq(users.institutionId, 1))).limit(1);
        if (!target) throw new TRPCError({ code: "NOT_FOUND", message: "Usuário não encontrado." });
        if (ctx.user.id === target.id) throw new TRPCError({ code: "BAD_REQUEST", message: "Use a página Minha senha para alterar sua própria senha." });
        if (!target.email) throw new TRPCError({ code: "BAD_REQUEST", message: "Este usuário ainda não tem e-mail cadastrado." });
        const emailNormalized = normalizeEmail(target.email);
        const [emailOwner] = await tx.select({ userId: localCredentials.userId }).from(localCredentials)
          .where(eq(localCredentials.emailNormalized, emailNormalized)).limit(1);
        if (emailOwner && emailOwner.userId !== target.id) throw new TRPCError({ code: "CONFLICT", message: "Este e-mail está associado a outra conta local." });
        const [credential] = await tx.select({ id: localCredentials.id }).from(localCredentials)
          .where(eq(localCredentials.userId, target.id)).limit(1);
        if (credential) {
          await tx.update(localCredentials).set({ emailNormalized, passwordHash }).where(eq(localCredentials.id, credential.id));
        } else {
          await tx.insert(localCredentials).values({ userId: target.id, emailNormalized, passwordHash });
        }
        await tx.update(users).set({ loginMethod: "email-password", sessionVersion: sql`${users.sessionVersion} + 1` }).where(eq(users.id, target.id));
        await audit(ctx.user.id, "usuario.senha_redefinida", "usuario", target.id, undefined, tx);
      });
      return { success: true };
    }),
    setRole: adminProcedure.input(z.object({ id: z.number().int().positive(), role })).mutation(async ({ ctx, input }) => {
      const db = await database();
      if (ctx.user.id === input.id && input.role !== "admin") throw new TRPCError({ code: "BAD_REQUEST", message: "Você não pode remover seu próprio acesso de administrador." });
      await db.transaction(async tx => {
        const [target] = await tx.select({ id: users.id }).from(users).where(and(eq(users.id, input.id), eq(users.institutionId, 1))).limit(1);
        if (!target) throw new TRPCError({ code: "NOT_FOUND", message: "Usuário não encontrado." });
        await tx.update(users).set({ role: input.role }).where(eq(users.id, input.id));
        await audit(ctx.user.id, "usuario.perfil_alterado", "usuario", input.id, { role: input.role }, tx);
      });
      return { success: true };
    }),
  }),

  audit: router({
    list: adminProcedure.input(z.object({ limit: z.number().int().min(1).max(200).default(100) }).optional()).query(async ({ input }) => {
      const db = await database();
      return db.select({ id: auditLogs.id, actorName: users.name, action: auditLogs.action, entityType: auditLogs.entityType, entityId: auditLogs.entityId, details: auditLogs.details, createdAt: auditLogs.createdAt })
        .from(auditLogs).leftJoin(users, eq(auditLogs.actorId, users.id)).where(eq(auditLogs.institutionId, 1))
        .orderBy(desc(auditLogs.createdAt)).limit(input?.limit ?? 100);
    }),
  }),
});
