import { systemRouter } from "./_core/systemRouter";
import { router } from "./_core/trpc";
import { authRouter } from "./authRouter";
import { sigdeRouter } from "./sigdeRouter";

export const appRouter = router({
  system: systemRouter,
  auth: authRouter,
  sigde: sigdeRouter,
});

export type AppRouter = typeof appRouter;
