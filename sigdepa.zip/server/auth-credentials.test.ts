import { describe, expect, it } from "vitest";
import { clearFailedAttempts, hashPassword, isRateLimited, makeAttemptKey, makeRateLimitBucket, normalizeEmail, recordFailedAttempt, safeCompareText, validatePassword, verifyPassword } from "./auth-credentials";

describe("credenciais locais do SIGDE", () => {
  it("normaliza e-mail sem remover caracteres válidos", () => {
    expect(normalizeEmail("  Secretaria.Exemplo@Escola.PA  ")).toBe("secretaria.exemplo@escola.pa");
  });

  it("gera buckets HMAC opacos, determinísticos e separados por escopo", () => {
    const email = "usuario@escola.pa";
    const key = makeRateLimitBucket("email", email);
    expect(key).toMatch(/^[a-f0-9]{64}$/);
    expect(key).not.toContain(email);
    expect(makeRateLimitBucket("email", email)).toBe(key);
    expect(makeRateLimitBucket("ip", email)).not.toBe(key);
  });

  it("armazena um hash Scrypt não reversível e verifica a senha", async () => {
    const password = "Senha forte para teste 2026!";
    const encoded = await hashPassword(password);
    expect(encoded).not.toContain(password);
    expect(encoded.startsWith("sigde-scrypt-v1$")).toBe(true);
    expect(await verifyPassword(password, encoded)).toBe(true);
    expect(await verifyPassword("Outra senha incorreta", encoded)).toBe(false);
  });

  it("exige pelo menos 12 caracteres para novas senhas", () => {
    expect(() => validatePassword("curta" )).toThrow("pelo menos 12 caracteres");
  });

  it("compara tokens sem depender de igualdade de strings simples", () => {
    expect(safeCompareText("token-a", "token-a")).toBe(true);
    expect(safeCompareText("token-a", "token-b")).toBe(false);
  });

  it("limita tentativas por IP e identidade e libera após a janela", () => {
    const key = makeAttemptKey("203.0.113.10", "usuario@escola.pa");
    clearFailedAttempts(key);
    for (let index = 0; index < 8; index += 1) recordFailedAttempt(key, 10_000 + index);
    expect(isRateLimited(key, 10_100)).toBe(true);
    expect(isRateLimited(key, 10_000 + 15 * 60 * 1000)).toBe(false);
    clearFailedAttempts(key);
  });
});
