import { createHash, createHmac, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";

const SCRYPT_N = 32_768;
const SCRYPT_R = 8;
const SCRYPT_P = 1;
const KEY_LENGTH = 64;
const MAXMEM = 64 * 1024 * 1024;
const HASH_SCHEME = "sigde-scrypt-v1";
const DUMMY_SALT = Buffer.alloc(16, 0x5a);
export const MAX_LOGIN_FAILURES = 8;
export const LOGIN_WINDOW_MS = 15 * 60 * 1000;

type ScryptOptions = { N: number; r: number; p: number; maxmem: number };

function deriveKey(password: string, salt: Buffer, options: ScryptOptions = { N: SCRYPT_N, r: SCRYPT_R, p: SCRYPT_P, maxmem: MAXMEM }) {
  return new Promise<Buffer>((resolve, reject) => {
    scryptCallback(password, salt, KEY_LENGTH, options, (error, result) => {
      if (error) reject(error);
      else resolve(result as Buffer);
    });
  });
}

export function normalizeEmail(email: string) {
  return email.trim().toLocaleLowerCase("en-US");
}

export function validatePassword(password: string) {
  if (password.length < 12) throw new Error("A senha precisa ter pelo menos 12 caracteres.");
  if (Buffer.byteLength(password, "utf8") > 512) throw new Error("A senha excede o tamanho permitido.");
}

export async function hashPassword(password: string) {
  validatePassword(password);
  const salt = randomBytes(16);
  const derived = await deriveKey(password, salt);
  return `${HASH_SCHEME}$${SCRYPT_N}$${SCRYPT_R}$${SCRYPT_P}$${salt.toString("base64url")}$${derived.toString("base64url")}`;
}

export async function verifyPassword(password: string, encoded: string) {
  const parts = encoded.split("$");
  const [scheme, nText, rText, pText, saltText, keyText] = parts;
  const structurallyValid = parts.length === 6 && scheme === HASH_SCHEME && Number(nText) === SCRYPT_N && Number(rText) === SCRYPT_R && Number(pText) === SCRYPT_P;
  const salt = structurallyValid ? Buffer.from(saltText, "base64url") : DUMMY_SALT;
  const expected = structurallyValid ? Buffer.from(keyText, "base64url") : Buffer.alloc(KEY_LENGTH);
  if (salt.length !== 16 || expected.length !== KEY_LENGTH) {
    await deriveKey(password, DUMMY_SALT);
    return false;
  }
  const actual = await deriveKey(password, salt);
  return timingSafeEqual(actual, expected) && structurallyValid;
}

export function safeCompareText(left: string, right: string) {
  const leftHash = createHash("sha256").update(left, "utf8").digest();
  const rightHash = createHash("sha256").update(right, "utf8").digest();
  return timingSafeEqual(leftHash, rightHash);
}

function hmacKey() {
  return process.env.MANUS_JWT_SECRET ?? "sigde-attempt-key-development-only";
}

export function makeAttemptKey(ipAddress: string, identity: string) {
  return createHmac("sha256", hmacKey()).update(`${ipAddress}\u0000${identity}`, "utf8").digest("hex");
}

export function makeRateLimitBucket(scope: string, value: string) {
  return createHmac("sha256", hmacKey()).update(`${scope}\u0000${value}`, "utf8").digest("hex");
}

type AttemptState = { count: number; windowStartedAt: number };
const attempts = new Map<string, AttemptState>();

export function isRateLimited(key: string, now = Date.now()) {
  const state = attempts.get(key);
  if (!state) return false;
  if (now - state.windowStartedAt >= LOGIN_WINDOW_MS) {
    attempts.delete(key);
    return false;
  }
  return state.count >= MAX_LOGIN_FAILURES;
}

export function recordFailedAttempt(key: string, now = Date.now()) {
  const current = attempts.get(key);
  if (!current || now - current.windowStartedAt >= LOGIN_WINDOW_MS) {
    attempts.set(key, { count: 1, windowStartedAt: now });
  } else {
    current.count += 1;
  }
  if (attempts.size > 5_000) {
    for (const [entryKey, state] of attempts) {
      if (now - state.windowStartedAt >= LOGIN_WINDOW_MS) attempts.delete(entryKey);
    }
  }
}

export function clearFailedAttempts(key: string) {
  attempts.delete(key);
}

export const dummyPasswordHash = `${HASH_SCHEME}$${SCRYPT_N}$${SCRYPT_R}$${SCRYPT_P}$${DUMMY_SALT.toString("base64url")}$${Buffer.alloc(KEY_LENGTH).toString("base64url")}`;
